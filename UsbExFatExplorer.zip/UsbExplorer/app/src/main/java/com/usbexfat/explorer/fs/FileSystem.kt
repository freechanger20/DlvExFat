package com.usbexfat.explorer.fs

import java.io.IOException
import java.io.InputStream

class FsEntry(
    val name: String,
    val isDir: Boolean,
    val size: Long,
    /** Modification time, ms since epoch (0 = unknown). */
    val mtime: Long,
    internal val firstCluster: Long,
    /** exFAT "NoFatChain": clusters are contiguous, FAT is not used. */
    internal val contiguous: Boolean = false,
    /** exFAT ValidDataLength; bytes after it read as zeros. */
    internal val validSize: Long = size,
)

interface FileSystem {
    val typeName: String
    val label: String
    val root: FsEntry

    @Throws(IOException::class)
    fun list(dir: FsEntry): List<FsEntry>

    @Throws(IOException::class)
    fun open(file: FsEntry): InputStream
}

/** A run of consecutive clusters. */
internal class Run(val first: Long, val count: Long)

/**
 * Reads a file stored in cluster runs. Supports skip() without reading data.
 */
internal class RunInputStream(
    private val dev: ByteDevice,
    private val runs: List<Run>,
    private val clusterSize: Long,
    private val clusterPos: (Long) -> Long,
    private val length: Long,
    private val validLength: Long,
) : InputStream() {
    private var pos = 0L
    private val one = ByteArray(1)

    override fun read(): Int = if (read(one, 0, 1) <= 0) -1 else one[0].toInt() and 0xFF

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (pos >= length) return -1
        var want = minOf(len.toLong(), length - pos).toInt()
        if (pos >= validLength) {
            java.util.Arrays.fill(b, off, off + want, 0)
            pos += want
            return want
        }
        want = minOf(want.toLong(), validLength - pos).toInt()
        val clusterIdx = pos / clusterSize
        val inCluster = pos % clusterSize
        // Binary search for the run containing clusterIdx
        var lo = 0
        var hi = runs.size - 1
        var found = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (runStart[mid] <= clusterIdx) { found = mid; lo = mid + 1 } else hi = mid - 1
        }
        if (found < 0 || clusterIdx >= runStart[found] + runs[found].count) {
            throw IOException("Цепочка кластеров короче размера файла")
        }
        val r = runs[found]
        val inRun = clusterIdx - runStart[found]
        val runBytesLeft = (r.count - inRun) * clusterSize - inCluster
        val n = minOf(want.toLong(), runBytesLeft).toInt()
        dev.read(clusterPos(r.first + inRun) + inCluster, b, off, n)
        pos += n
        return n
    }

    private val runStart = LongArray(runs.size).also {
        var acc = 0L
        for (i in runs.indices) { it[i] = acc; acc += runs[i].count }
    }

    override fun skip(n: Long): Long {
        if (n <= 0) return 0
        val s = minOf(n, length - pos)
        pos += s
        return s
    }

    override fun available(): Int = minOf(Int.MAX_VALUE.toLong(), length - pos).toInt()
}

@Throws(IOException::class)
fun mountPartition(dev: ByteDevice, p: Partition): FileSystem = when (p.fsType) {
    FsType.EXFAT -> ExFatFs(dev, p.start)
    FsType.FAT12, FsType.FAT16, FsType.FAT32 -> FatFs(dev, p.start)
    else -> throw IOException("Файловая система ${p.fsType.title} не поддерживается")
}
