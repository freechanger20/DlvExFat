package com.usbexfat.explorer

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

/** Serves files copied to cache/open so other apps can open them. */
class CacheProvider : ContentProvider() {
    override fun onCreate() = true

    private fun file(uri: Uri): File {
        val dir = openDir(context!!.cacheDir)
        val name = uri.lastPathSegment ?: throw FileNotFoundException()
        val f = File(dir, name)
        if (f.canonicalFile.parentFile != dir.canonicalFile) throw FileNotFoundException()
        return f
    }

    override fun getType(uri: Uri): String = mimeOf(uri.lastPathSegment ?: "")

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor =
        ParcelFileDescriptor.open(file(uri), ParcelFileDescriptor.MODE_READ_ONLY)

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val f = file(uri)
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val c = MatrixCursor(cols)
        c.addRow(cols.map { col ->
            when (col) {
                OpenableColumns.DISPLAY_NAME -> f.name
                OpenableColumns.SIZE -> f.length()
                else -> null
            }
        })
        return c
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?) = 0

    companion object {
        const val AUTHORITY = "com.usbexfat.explorer.files"
        fun openDir(cache: File) = File(cache, "open").also { it.mkdirs() }
        fun uriFor(name: String): Uri = Uri.Builder().scheme("content").authority(AUTHORITY).appendPath(name).build()
    }
}

fun mimeOf(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase()
    if (ext.isEmpty()) return "application/octet-stream"
    return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        ?: when (ext) {
            "iso", "img" -> "application/x-iso9660-image"
            "cfg", "conf", "ini", "log", "md" -> "text/plain"
            else -> "application/octet-stream"
        }
}
