package com.usbexfat.explorer.zip

import java.io.IOException
import java.io.InputStream
import java.nio.charset.Charset
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream

/** Random-access source: reads at absolute position, returns -1 at EOF. */
fun interface ReadAt {
    fun read(pos: Long, b: ByteArray, off: Int, len: Int): Int
}

class ZipEntryInfo(
    val path: String,
    val isDir: Boolean,
    val size: Long,
    val compSize: Long,
    val method: Int,
    val encrypted: Boolean,
    val mtime: Long,
    internal val localOffset: Long,
)

/**
 * Minimal ZIP reader working on top of random access: lists the central directory
 * and extracts single entries without reading the whole archive. Supports Zip64,
 * stored/deflated entries and CP866 names from Windows archivers.
 */
class ZipReader(private val src: ReadAt, private val size: Long) {

    val entries: List<ZipEntryInfo>

    init {
        entries = readCentral()
    }

    private fun readFully(pos: Long, n: Int): ByteArray {
        val b = ByteArray(n)
        var got = 0
        while (got < n) {
            val r = src.read(pos + got, b, got, n - got)
            if (r <= 0) throw IOException("Архив обрезан")
            got += r
        }
        return b
    }

    private fun ByteArray.u16(i: Int) = (this[i].toInt() and 0xFF) or ((this[i + 1].toInt() and 0xFF) shl 8)
    private fun ByteArray.u32(i: Int) = u16(i).toLong() or (u16(i + 2).toLong() shl 16)
    private fun ByteArray.u64(i: Int) = u32(i) or (u32(i + 4) shl 32)

    private fun readCentral(): List<ZipEntryInfo> {
        if (size < 22) throw IOException("Это не ZIP-архив")
        val tailLen = minOf(size, 65_557L).toInt()
        val tailPos = size - tailLen
        val tail = readFully(tailPos, tailLen)
        var eocd = -1
        for (i in tailLen - 22 downTo 0) {
            if (tail[i].toInt() == 0x50 && tail[i + 1].toInt() == 0x4B && tail[i + 2].toInt() == 5 && tail[i + 3].toInt() == 6) { eocd = i; break }
        }
        if (eocd < 0) throw IOException("Это не ZIP-архив (нет оглавления)")
        var count = tail.u16(eocd + 10).toLong()
        var cdSize = tail.u32(eocd + 12)
        var cdOff = tail.u32(eocd + 16)
        // Zip64 locator right before EOCD
        if (eocd >= 20 && tail.u32(eocd - 20) == 0x07064b50L) {
            val z64 = tail.u64(eocd - 20 + 8)
            val rec = readFully(z64, 56)
            if (rec.u32(0) == 0x06064b50L) {
                count = rec.u64(32); cdSize = rec.u64(40); cdOff = rec.u64(48)
            }
        }
        if (cdSize > 128L * 1024 * 1024 || cdOff + cdSize > size) throw IOException("Повреждённое оглавление архива")
        val cd = readFully(cdOff, cdSize.toInt())
        val cp866 = try { Charset.forName("CP866") } catch (e: Exception) { Charsets.ISO_8859_1 }
        val out = ArrayList<ZipEntryInfo>()
        var p = 0
        var n = 0L
        while (p + 46 <= cd.size && n < count) {
            if (cd.u32(p) != 0x02014b50L) break
            val flags = cd.u16(p + 8)
            val method = cd.u16(p + 10)
            val time = cd.u16(p + 12)
            val date = cd.u16(p + 14)
            var comp = cd.u32(p + 20)
            var uncomp = cd.u32(p + 24)
            val nameLen = cd.u16(p + 28)
            val extraLen = cd.u16(p + 30)
            val commentLen = cd.u16(p + 32)
            var local = cd.u32(p + 42)
            val nameBytes = cd.copyOfRange(p + 46, p + 46 + nameLen)
            var name = if (flags and 0x800 != 0) String(nameBytes, Charsets.UTF_8) else decodeName(nameBytes, cp866)
            // Info-ZIP Unicode Path extra field + Zip64
            var e = p + 46 + nameLen
            val eEnd = e + extraLen
            while (e + 4 <= eEnd) {
                val id = cd.u16(e)
                val sz = cd.u16(e + 2)
                val d = e + 4
                if (id == 0x0001) {
                    var q = d
                    if (uncomp == 0xFFFFFFFFL && q + 8 <= d + sz) { uncomp = cd.u64(q); q += 8 }
                    if (comp == 0xFFFFFFFFL && q + 8 <= d + sz) { comp = cd.u64(q); q += 8 }
                    if (local == 0xFFFFFFFFL && q + 8 <= d + sz) { local = cd.u64(q) }
                } else if (id == 0x7075 && sz > 5) {
                    name = String(cd, d + 5, sz - 5, Charsets.UTF_8)
                }
                e = d + sz
            }
            name = name.replace('\\', '/')
            val isDir = name.endsWith("/")
            out += ZipEntryInfo(name.trimEnd('/'), isDir, uncomp, comp, method, flags and 1 != 0, dosTime(date, time), local)
            p += 46 + nameLen + extraLen + commentLen
            n++
        }
        return out
    }

    private fun decodeName(b: ByteArray, cp866: Charset): String {
        // Valid UTF-8 without the flag is common (macOS, 7-Zip); otherwise assume DOS Cyrillic
        val dec = Charsets.UTF_8.newDecoder()
        return try { dec.decode(java.nio.ByteBuffer.wrap(b)).toString() } catch (e: Exception) { String(b, cp866) }
    }

    private fun dosTime(date: Int, time: Int): Long {
        if (date == 0) return 0
        val c = java.util.Calendar.getInstance()
        c.clear()
        c.set(1980 + (date ushr 9), ((date ushr 5) and 0xF) - 1, date and 0x1F, time ushr 11, (time ushr 5) and 0x3F, (time and 0x1F) * 2)
        return c.timeInMillis
    }

    fun open(e: ZipEntryInfo): InputStream {
        if (e.encrypted) throw IOException("Файл в архиве защищён паролем")
        val lh = readFully(e.localOffset, 30)
        if (lh.u32(0) != 0x04034b50L) throw IOException("Повреждённая запись архива")
        val dataPos = e.localOffset + 30 + lh.u16(26) + lh.u16(28)
        return when (e.method) {
            0 -> RangeStream(src, dataPos, e.compSize, false)
            // nowrap Inflater may need one extra dummy byte after the data (same trick as java.util.zip.ZipFile)
            8 -> InflaterInputStream(RangeStream(src, dataPos, e.compSize, true), Inflater(true), 64 * 1024)
            else -> throw IOException("Метод сжатия ${e.method} не поддерживается — откройте архив в ZArchiver или RAR")
        }
    }

    private class RangeStream(private val src: ReadAt, private val start: Long, private val len: Long, private val pad: Boolean) : InputStream() {
        private var pos = 0L
        private var padded = false
        override fun read(): Int {
            val b = ByteArray(1)
            return if (read(b, 0, 1) <= 0) -1 else b[0].toInt() and 0xFF
        }
        override fun read(b: ByteArray, off: Int, n: Int): Int {
            if (pos >= len) {
                if (pad && !padded && n > 0) { padded = true; b[off] = 0; return 1 }
                return -1
            }
            val want = minOf(n.toLong(), len - pos).toInt()
            val r = src.read(start + pos, b, off, want)
            if (r <= 0) return -1
            pos += r
            return r
        }
    }
}
