package com.usbexfat.explorer

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast

private val TEXT_EXT = setOf(
    "txt", "text", "log", "md", "markdown", "rst", "csv", "tsv", "nfo", "diz", "srt", "ass", "ssa", "sub", "vtt",
    "json", "xml", "yml", "yaml", "toml", "ini", "cfg", "conf", "config", "properties", "env", "reg", "inf",
    "htm", "html", "xhtml", "css", "scss", "sass", "less", "js", "mjs", "cjs", "tsx", "jsx", "vue", "svelte",
    "py", "pyw", "kt", "kts", "java", "gradle", "groovy", "scala", "c", "h", "cpp", "cc", "cxx", "hpp", "hh", "cs",
    "go", "rs", "rb", "php", "pl", "pm", "lua", "sql", "swift", "m", "mm", "dart", "r", "jl", "hs", "ex", "exs",
    "erl", "clj", "lisp", "el", "vim", "asm", "s", "pas", "dpr", "bas", "vb", "vbs", "ps1", "psm1", "sh", "bash",
    "zsh", "fish", "bat", "cmd", "mk", "cmake", "make", "dockerfile", "gitignore", "gitattributes", "editorconfig",
    "tex", "bib", "patch", "diff", "lst", "list", "sfv", "md5", "sha1", "sha256", "cue", "m3u", "m3u8", "pls",
)

private val EXTRA_MIME = mapOf(
    "md" to "text/markdown", "json" to "application/json", "yml" to "text/yaml", "yaml" to "text/yaml",
    "csv" to "text/csv", "js" to "text/javascript", "mjs" to "text/javascript", "css" to "text/css",
    "py" to "text/x-python", "java" to "text/x-java", "kt" to "text/x-kotlin", "c" to "text/x-c", "h" to "text/x-c",
    "cpp" to "text/x-c++src", "sh" to "application/x-sh", "sql" to "application/sql",
    "doc" to "application/msword", "docx" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "xls" to "application/vnd.ms-excel", "xlsx" to "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "ppt" to "application/vnd.ms-powerpoint", "pptx" to "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "odt" to "application/vnd.oasis.opendocument.text", "ods" to "application/vnd.oasis.opendocument.spreadsheet",
    "rtf" to "application/rtf", "pdf" to "application/pdf", "epub" to "application/epub+zip",
    "fb2" to "application/x-fictionbook+xml", "djvu" to "image/vnd.djvu", "djv" to "image/vnd.djvu",
    "zip" to "application/zip", "rar" to "application/vnd.rar", "7z" to "application/x-7z-compressed",
    "tar" to "application/x-tar", "gz" to "application/gzip", "tgz" to "application/gzip", "xz" to "application/x-xz",
    "bz2" to "application/x-bzip2", "zst" to "application/zstd",
    "apk" to "application/vnd.android.package-archive", "apks" to "application/octet-stream",
    "mkv" to "video/x-matroska", "webm" to "video/webm", "ts" to "video/mp2t", "m4a" to "audio/mp4", "opus" to "audio/ogg",
    "flac" to "audio/flac", "heic" to "image/heic", "webp" to "image/webp", "svg" to "image/svg+xml",
    "iso" to "application/x-iso9660-image", "img" to "application/octet-stream",
)

fun extOf(name: String) = name.substringAfterLast('.', "").lowercase()

fun mimeOf(name: String): String {
    val ext = extOf(name)
    if (ext.isEmpty()) return "application/octet-stream"
    EXTRA_MIME[ext]?.let { return it }
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { return it }
    return if (ext in TEXT_EXT) "text/plain" else "application/octet-stream"
}

fun isTextFile(name: String): Boolean = extOf(name) in TEXT_EXT ||
    name.lowercase() in setOf("readme", "license", "makefile", "dockerfile", "changelog", "authors")

fun isZipFile(name: String): Boolean = extOf(name) in setOf("zip", "jar", "apk", "epub", "cbz", "xpi", "aar", "apks", "xapk")

object Opener {

    private fun viewIntent(uri: Uri, mime: String) = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

    /**
     * Opens a file in the phone's default app for its type.
     * If no app can handle it, falls back to the built-in text or ZIP viewer.
     */
    fun open(a: Activity, uri: Uri, name: String) {
        val mimes = LinkedHashSet<String>()
        mimes += mimeOf(name)
        if (isTextFile(name)) mimes += "text/plain"
        for (m in mimes) {
            if (m == "application/octet-stream") continue
            try {
                a.startActivity(viewIntent(uri, m))
                return
            } catch (_: ActivityNotFoundException) {
            } catch (e: SecurityException) {
                Toast.makeText(a, "Приложение отказалось открыть файл: ${e.message}", Toast.LENGTH_LONG).show()
                return
            }
        }
        when {
            isTextFile(name) -> TextViewerActivity.start(a, uri, name)
            isZipFile(name) -> ArchiveActivity.start(a, uri, name)
            else -> openWith(a, uri, name, "*/*")
        }
    }

    /** Lets the user pick any app ("Открыть с помощью…"). */
    fun openWith(a: Activity, uri: Uri, name: String, mime: String = mimeOf(name)) {
        val i = viewIntent(uri, if (mime == "application/octet-stream") "*/*" else mime)
        try {
            a.startActivity(Intent.createChooser(i, "Открыть «$name» с помощью"))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(a, "Нет приложения для этого типа файлов. Попробуйте «Просмотреть как текст».", Toast.LENGTH_LONG).show()
        }
    }

    fun share(a: Activity, uri: Uri, name: String) {
        val i = Intent(Intent.ACTION_SEND).setType(mimeOf(name)).putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { a.startActivity(Intent.createChooser(i, "Поделиться")) } catch (_: ActivityNotFoundException) {}
    }
}
