package com.usbexfat.explorer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.TextUtils
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import com.usbexfat.explorer.zip.ZipEntryInfo
import com.usbexfat.explorer.zip.ZipReader
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** Built-in ZIP browser: lists the archive without unpacking it, extracts single files on demand. */
class ArchiveActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()
    private lateinit var uri: Uri
    private lateinit var name: String
    private var pfd: ParcelFileDescriptor? = null
    private var channel: FileChannel? = null
    private var zip: ZipReader? = null
    private var prefix = "" // current folder inside the archive, "" or "a/b/"
    private val scroll = ArrayList<Int>()

    private lateinit var pathView: TextView
    private lateinit var busy: ProgressBar
    private lateinit var list: ListView
    private val adapter by lazy { RowsAdapter(this) }
    private val dateFmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    private var pendingSave: ZipEntryInfo? = null

    private class Dir(val path: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        uri = intent.data ?: return finish()
        name = intent.getStringExtra(EXTRA_NAME) ?: "Архив"
        title = name
        actionBar?.setDisplayHomeAsUpEnabled(true)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pathView = TextView(this).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            ellipsize = TextUtils.TruncateAt.START
            isSingleLine = true
            setBackgroundColor(0x22808080)
        }
        busy = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { isIndeterminate = true }
        list = ListView(this).apply {
            adapter = this@ArchiveActivity.adapter
            onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ -> click(this@ArchiveActivity.adapter.rows[pos]) }
            onItemLongClickListener = AdapterView.OnItemLongClickListener { _, _, pos, _ ->
                (this@ArchiveActivity.adapter.rows[pos].payload as? ZipEntryInfo)?.let { menu(it) }; true
            }
        }
        root.addView(pathView, LinearLayout.LayoutParams(-1, -2))
        root.addView(busy, LinearLayout.LayoutParams(-1, dp(4)))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        io.execute {
            val res = runCatching {
                val fd = contentResolver.openFileDescriptor(uri, "r") ?: throw java.io.IOException("Не удалось открыть файл")
                pfd = fd
                val ch = FileInputStream(fd.fileDescriptor).channel
                channel = ch
                val size = if (fd.statSize >= 0) fd.statSize else ch.size()
                ZipReader({ pos, b, off, len -> ch.read(ByteBuffer.wrap(b, off, len), pos) }, size)
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                busy.visibility = View.INVISIBLE
                res.fold({ zip = it; show() }, {
                    AlertDialog.Builder(this).setTitle("Не удалось открыть архив").setMessage(it.message ?: it.toString())
                        .setPositiveButton("OK") { _, _ -> finish() }.show()
                })
            }
        }
    }

    override fun onDestroy() {
        io.execute { try { channel?.close(); pfd?.close() } catch (_: Exception) {} }
        io.shutdown()
        super.onDestroy()
    }

    private fun show(selection: Int = 0) {
        val z = zip ?: return
        val dirs = sortedSetOf(String.CASE_INSENSITIVE_ORDER)
        val files = ArrayList<ZipEntryInfo>()
        for (e in z.entries) {
            if (!e.path.startsWith(prefix) || e.path.length <= prefix.length) continue
            val rest = e.path.substring(prefix.length)
            val slash = rest.indexOf('/')
            when {
                slash >= 0 -> dirs += rest.substring(0, slash)
                e.isDir -> dirs += rest
                else -> files += e
            }
        }
        files.sortBy { it.path.lowercase() }
        val rows = ArrayList<Row>()
        for (d in dirs) rows += Row("📁", d, "", true, Dir(prefix + d + "/"))
        for (f in files) {
            val n = f.path.substringAfterLast('/')
            val sub = listOfNotNull(fmtSize(f.size), if (f.mtime > 0) dateFmt.format(Date(f.mtime)) else null,
                if (f.encrypted) "🔒 пароль" else null).joinToString(" · ")
            rows += Row(iconFor(n), n, sub, true, f)
        }
        adapter.rows = rows
        pathView.text = "$name/$prefix"
        actionBar?.subtitle = "${z.entries.count { !it.isDir }} файлов в архиве"
        list.setSelection(selection)
    }

    private fun click(r: Row) {
        when (val p = r.payload) {
            is Dir -> { scroll += list.firstVisiblePosition; prefix = p.path; show() }
            is ZipEntryInfo -> extract(p) { f -> Opener.open(this, FilesProvider.cacheUri(f.name), f.name) }
        }
    }

    private fun menu(e: ZipEntryInfo) {
        val n = e.path.substringAfterLast('/')
        AlertDialog.Builder(this).setTitle(n)
            .setItems(arrayOf("Открыть", "Открыть с помощью…", "Просмотреть как текст", "Сохранить на телефон…", "Поделиться")) { _, w ->
                when (w) {
                    0 -> extract(e) { f -> Opener.open(this, FilesProvider.cacheUri(f.name), f.name) }
                    1 -> extract(e) { f -> Opener.openWith(this, FilesProvider.cacheUri(f.name), f.name) }
                    2 -> extract(e) { f -> TextViewerActivity.start(this, FilesProvider.cacheUri(f.name), f.name) }
                    3 -> {
                        pendingSave = e
                        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                            .setType(mimeOf(n)).putExtra(Intent.EXTRA_TITLE, n), REQ_SAVE)
                    }
                    4 -> extract(e) { f -> Opener.share(this, FilesProvider.cacheUri(f.name), f.name) }
                }
            }.show()
    }

    private fun extract(e: ZipEntryInfo, then: (File) -> Unit) {
        val z = zip ?: return
        val dir = FilesProvider.cacheDir(this)
        if (e.size > dir.usableSpace - 50L * 1024 * 1024) { toast("Недостаточно места во внутренней памяти"); return }
        val out = File(dir, safeName(e.path.substringAfterLast('/')))
        runJob("Извлечение", e.size, io, { p ->
            cleanOpenCache(this)
            p.setFile(out.name)
            out.outputStream().use { o -> z.open(e).use { copyWithProgress(it, o, p) } }
            if (p.cancelled) out.delete()
            out
        }, then)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        val target = data?.data
        val e = pendingSave
        if (requestCode != REQ_SAVE || resultCode != RESULT_OK || target == null || e == null) return
        val z = zip ?: return
        runJob("Сохранение", e.size, io, { p ->
            contentResolver.openOutputStream(target, "w")!!.use { o -> z.open(e).use { copyWithProgress(it, o, p) } }
        }) { toast("Сохранено") }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (prefix.isEmpty()) { @Suppress("DEPRECATION") super.onBackPressed(); return }
        prefix = prefix.dropLast(1).substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
        show(scroll.removeLastOrNull() ?: 0)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Открыть архив в другом приложении…")
        return true
    }

    @Suppress("DEPRECATION")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> onBackPressed()
            1 -> Opener.openWith(this, uri, name)
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    companion object {
        private const val EXTRA_NAME = "name"
        private const val REQ_SAVE = 10

        fun start(a: Activity, uri: Uri, name: String) {
            a.startActivity(Intent(a, ArchiveActivity::class.java).setData(uri).putExtra(EXTRA_NAME, name)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }
    }
}
