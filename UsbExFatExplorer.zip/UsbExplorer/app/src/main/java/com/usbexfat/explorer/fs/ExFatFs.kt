package com.usbexfat.explorer.fs

import java.io.IOException
import java.io.InputStream
import java.util.Calendar
import java.util.TimeZone

/** Read-only exFAT driver. */
class ExFatFs(private val dev: ByteDevice, private val base: Long) : FileSystem {
    override val typeName = "exFAT"
    override val label: String
    override val root: FsEntry

    private val bytesPerSector: Long
    val clusterSize: Long
    private val fatPos: Long
    private val heapPos: Long
    private val clusterCount: Long

    init {
        val b = dev.read(base, 512)
        if (b.ascii(3, 8) != "EXFAT   ") throw IOException("Это не exFAT")
        val bpsShift = b.u8(108)
        val spcShift = b.u8(109)
        if (bpsShift !in 9..12 || spcShift > 25 - bpsShift) throw IOException("Повреждён загрузочный сектор exFAT")
        bytesPerSector = 1L shl bpsShift
        clusterSize = bytesPerSector shl spcShift
        val fatOffset = b.u32(80)
        val fatLength = b.u32(84)
        val numFats = b.u8(110)
        val activeFat = if (numFats == 2 && (b.u16(106) and 1) == 1) 1 else 0
        fatPos = base + (fatOffset + activeFat * fatLength) * bytesPerSector
        heapPos = base + b.u32(88) * bytesPerSector
        clusterCount = b.u32(92)
        val rootCluster = b.u32(96)
        root = FsEntry("", true, 0, 0, rootCluster, contiguous = false, validSize = -1)
        label = readLabel()
    }

    private fun clusterPos(c: Long): Long = heapPos + (c - 2) * clusterSize

    private fun validCluster(c: Long) = c >= 2 && c < clusterCount + 2

    private fun fatNext(c: Long): Long {
        val b = ByteArray(4)
        dev.read(fatPos + c * 4, b, 0, 4)
        return b.u32(0)
    }

    /** length < 0 means "follow FAT chain to the end" (root directory). */
    private fun runs(first: Long, contiguous: Boolean, length: Long): List<Run> {
        if (length == 0L || first == 0L) return emptyList()
        if (!validCluster(first)) throw IOException("Неверный номер кластера $first")
        if (contiguous) {
            val n = (length + clusterSize - 1) / clusterSize
            return listOf(Run(first, n))
        }
        val need = if (length < 0) Long.MAX_VALUE else (length + clusterSize - 1) / clusterSize
        val out = ArrayList<Run>()
        var runFirst = first
        var runLen = 1L
        var cur = first
        var total = 1L
        while (total < need) {
            val next = fatNext(cur)
            if (!validCluster(next)) {
                if (next >= 0xFFFFFFF7L || length < 0) break
                throw IOException("Обрыв цепочки кластеров ($cur → $next)")
            }
            if (next == cur + 1) runLen++ else {
                out += Run(runFirst, runLen); runFirst = next; runLen = 1
            }
            cur = next
            total++
            if (total > clusterCount) throw IOException("Зацикленная цепочка кластеров")
        }
        out += Run(runFirst, runLen)
        return out
    }

    private fun readDirBytes(dir: FsEntry): ByteArray {
        val len = if (dir === root || dir.validSize < 0) -1L else dir.size
        val rs = runs(dir.firstCluster, dir.contiguous, len)
        val total = rs.sumOf { it.count } * clusterSize
        if (total > 256L * 1024 * 1024) throw IOException("Слишком большой каталог")
        val bytes = ByteArray(total.toInt())
        var o = 0
        for (r in rs) {
            val n = (r.count * clusterSize).toInt()
            dev.read(clusterPos(r.first), bytes, o, n)
            o += n
        }
        return bytes
    }

    private fun readLabel(): String {
        return try {
            val d = readDirBytes(root)
            var i = 0
            while (i + 32 <= d.size) {
                val t = d.u8(i)
                if (t == 0) break
                if (t == 0x83) {
                    val n = d.u8(i + 1).coerceAtMost(11)
                    val sb = StringBuilder()
                    for (k in 0 until n) sb.append(d.u16(i + 2 + k * 2).toChar())
                    return sb.toString()
                }
                i += 32
            }
            ""
        } catch (e: IOException) { "" }
    }

    override fun list(dir: FsEntry): List<FsEntry> {
        val d = readDirBytes(dir)
        val out = ArrayList<FsEntry>()
        var i = 0
        while (i + 32 <= d.size) {
            val t = d.u8(i)
            if (t == 0) break
            if (t != 0x85) { i += 32; continue }
            val secCount = d.u8(i + 1)
            val setEnd = i + 32 * (secCount + 1)
            if (secCount < 2 || setEnd > d.size || d.u8(i + 32) != 0xC0) { i += 32; continue }
            if (checksum(d, i, secCount + 1) != d.u16(i + 2)) { i = setEnd; continue }
            val attrs = d.u16(i + 4)
            val mtime = exfatTime(d.u32(i + 12), d.u8(i + 21), d.u8(i + 23))
            val s = i + 32
            val flags = d.u8(s + 1)
            val nameLen = d.u8(s + 3)
            val validLen = d.u64(s + 8)
            val firstCluster = d.u32(s + 20)
            val dataLen = d.u64(s + 24)
            val sb = StringBuilder(nameLen)
            var e = s + 32
            while (sb.length < nameLen && e < setEnd) {
                if (d.u8(e) == 0xC1) {
                    for (k in 0 until 15) {
                        if (sb.length >= nameLen) break
                        sb.append(d.u16(e + 2 + k * 2).toChar())
                    }
                }
                e += 32
            }
            val isDir = (attrs and 0x10) != 0
            out += FsEntry(
                name = sb.toString(),
                isDir = isDir,
                size = dataLen,
                mtime = mtime,
                firstCluster = firstCluster,
                contiguous = (flags and 0x02) != 0,
                validSize = if (isDir) dataLen else minOf(validLen, dataLen),
            )
            i = setEnd
        }
        return out
    }

    override fun open(file: FsEntry): InputStream {
        val rs = runs(file.firstCluster, file.contiguous, file.size)
        return RunInputStream(dev, rs, clusterSize, ::clusterPos, file.size, file.validSize)
    }

    private fun checksum(d: ByteArray, start: Int, entries: Int): Int {
        var sum = 0
        for (k in 0 until entries * 32) {
            if (k == 2 || k == 3) continue
            sum = (((sum shl 15) or (sum ushr 1)) + d.u8(start + k)) and 0xFFFF
        }
        return sum
    }

    private fun exfatTime(ts: Long, tenMs: Int, utcOff: Int): Long {
        if (ts == 0L) return 0
        val v = ts.toInt()
        val cal = if (utcOff and 0x80 != 0) Calendar.getInstance(TimeZone.getTimeZone("UTC")) else Calendar.getInstance()
        cal.clear()
        cal.set(
            1980 + ((v ushr 25) and 0x7F), ((v ushr 21) and 0x0F) - 1, (v ushr 16) and 0x1F,
            (v ushr 11) and 0x1F, (v ushr 5) and 0x3F, (v and 0x1F) * 2,
        )
        var ms = cal.timeInMillis + tenMs * 10L
        if (utcOff and 0x80 != 0) {
            val off = (utcOff and 0x7F).let { if (it >= 0x40) it - 0x80 else it } // signed 7-bit, 15-minute units
            ms -= off * 15L * 60_000L
        }
        return ms
    }
}
