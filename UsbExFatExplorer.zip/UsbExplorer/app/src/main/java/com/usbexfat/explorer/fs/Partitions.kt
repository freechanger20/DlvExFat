package com.usbexfat.explorer.fs

import java.io.IOException

enum class FsType(val title: String, val supported: Boolean) {
    EXFAT("exFAT", true),
    FAT12("FAT12", true),
    FAT16("FAT16", true),
    FAT32("FAT32", true),
    NTFS("NTFS", true),
    EXT("ext2/3/4", false),
    UNKNOWN("неизвестно", false),
}

class Partition(
    val index: Int,
    val start: Long,
    val length: Long,
    val scheme: String,
    val fsType: FsType,
    val label: String,
    val gptName: String = "",
)

object Partitions {

    @Throws(IOException::class)
    fun scan(dev: ByteDevice): List<Partition> {
        val bs = dev.dev.blockSize.toLong()
        val mbr = dev.read(0, 512)
        val result = ArrayList<Partition>()

        val hasSig = mbr.u8(510) == 0x55 && mbr.u8(511) == 0xAA
        // Whole-disk filesystem without partition table ("superfloppy")
        val whole = detect(dev, 0, dev.size)
        if (whole.first != FsType.UNKNOWN && (whole.first == FsType.EXFAT || whole.first == FsType.NTFS ||
                !hasSig || !mbrLooksValid(mbr, dev.size, bs))) {
            result += Partition(1, 0, dev.size, "без таблицы", whole.first, whole.second.ifEmpty { fsLabel(dev, whole.first, 0) })
            return result
        }
        if (!hasSig) return result

        val entries = (0 until 4).map { i -> 446 + i * 16 }
        if (entries.any { mbr.u8(it + 4) == 0xEE }) {
            scanGpt(dev, bs, result)
            if (result.isNotEmpty()) return result
        }

        var n = 1
        for (e in entries) {
            val type = mbr.u8(e + 4)
            val startLba = mbr.u32(e + 8)
            val count = mbr.u32(e + 12)
            if (type == 0 || count == 0L) continue
            if (type == 0x05 || type == 0x0F || type == 0x85) {
                n = scanExtended(dev, bs, startLba, result, n)
                continue
            }
            if (type == 0xEE) continue
            add(dev, result, n++, startLba * bs, count * bs, "MBR 0x%02X".format(type))
        }
        return result
    }

    private fun mbrLooksValid(mbr: ByteArray, size: Long, bs: Long): Boolean {
        var any = false
        for (i in 0 until 4) {
            val e = 446 + i * 16
            val boot = mbr.u8(e)
            val type = mbr.u8(e + 4)
            if (boot != 0 && boot != 0x80) return false
            if (type == 0) continue
            val start = mbr.u32(e + 8)
            val cnt = mbr.u32(e + 12)
            if (start == 0L || cnt == 0L) return false
            if (type != 0xEE && (start + cnt) * bs > size + bs) return false
            any = true
        }
        return any
    }

    private fun add(dev: ByteDevice, out: MutableList<Partition>, idx: Int, start: Long, len: Long, scheme: String, gptName: String = "") {
        val realLen = minOf(len, dev.size - start)
        if (start >= dev.size || realLen <= 0) return
        val (type, label) = try { detect(dev, start, realLen) } catch (e: IOException) { FsType.UNKNOWN to "" }
        out += Partition(idx, start, realLen, scheme, type, label.ifEmpty { fsLabel(dev, type, start) }, gptName)
    }

    private fun scanExtended(dev: ByteDevice, bs: Long, extStart: Long, out: MutableList<Partition>, firstIdx: Int): Int {
        var idx = firstIdx
        var ebrLba = extStart
        var guard = 0
        while (guard++ < 128) {
            val ebr = dev.read(ebrLba * bs, 512)
            if (ebr.u8(510) != 0x55 || ebr.u8(511) != 0xAA) break
            val t1 = ebr.u8(446 + 4)
            val s1 = ebr.u32(446 + 8)
            val c1 = ebr.u32(446 + 12)
            if (t1 != 0 && c1 != 0L) add(dev, out, idx++, (ebrLba + s1) * bs, c1 * bs, "логический 0x%02X".format(t1))
            val t2 = ebr.u8(462 + 4)
            val s2 = ebr.u32(462 + 8)
            if (t2 == 0 || s2 == 0L) break
            ebrLba = extStart + s2
        }
        return idx
    }

    private fun scanGpt(dev: ByteDevice, bs: Long, out: MutableList<Partition>) {
        val hdr = dev.read(bs, 512)
        if (hdr.ascii(0, 8) != "EFI PART") return
        val entriesLba = hdr.u64(72)
        val num = hdr.u32(80).toInt().coerceIn(0, 1024)
        val esz = hdr.u32(84).toInt()
        if (esz < 128 || esz > 4096) return
        val table = dev.read(entriesLba * bs, num * esz)
        var idx = 1
        for (i in 0 until num) {
            val e = i * esz
            var empty = true
            for (k in 0 until 16) if (table[e + k].toInt() != 0) { empty = false; break }
            if (empty) continue
            val first = table.u64(e + 32)
            val last = table.u64(e + 40)
            if (last < first) continue
            val nameChars = CharArray(36)
            var nl = 0
            for (k in 0 until 36) {
                val c = table.u16(e + 56 + k * 2)
                if (c == 0) break
                nameChars[nl++] = c.toChar()
            }
            add(dev, out, idx++, first * bs, (last - first + 1) * bs, "GPT", String(nameChars, 0, nl))
        }
    }

    private fun fsLabel(dev: ByteDevice, type: FsType, start: Long): String = try {
        when (type) {
            FsType.EXFAT -> ExFatFs(dev, start).label
            FsType.NTFS -> NtfsFs(dev, start).label
            else -> ""
        }
    } catch (e: Exception) { "" }

    /** Returns filesystem type and its volume label. */
    fun detect(dev: ByteDevice, start: Long, len: Long): Pair<FsType, String> {
        if (len < 512) return FsType.UNKNOWN to ""
        val b = dev.read(start, 512)
        val oem = b.ascii(3, 8)
        if (oem == "EXFAT   ") return FsType.EXFAT to ""
        if (oem == "NTFS    ") return FsType.NTFS to ""
        FatFs.probe(b)?.let { return it }
        if (len >= 2048) {
            val sb = dev.read(start + 1024, 512)
            if (sb.u16(56) == 0xEF53) return FsType.EXT to ""
        }
        return FsType.UNKNOWN to ""
    }
}
