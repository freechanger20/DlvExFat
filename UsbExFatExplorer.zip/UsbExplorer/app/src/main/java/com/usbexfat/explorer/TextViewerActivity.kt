package com.usbexfat.explorer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** Built-in viewer for text and source code files. */
class TextViewerActivity : Activity() {

    private lateinit var uri: Uri
    private lateinit var name: String
    private var raw = ByteArray(0)
    private var truncated = false
    private var charset: Charset = Charsets.UTF_8
    private var wrap = true
    private var fontSp = 13f

    private lateinit var frame: FrameLayout
    private lateinit var text: TextView
    private lateinit var progress: ProgressBar
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        uri = intent.data ?: return finish()
        name = intent.getStringExtra(EXTRA_NAME) ?: uri.lastPathSegment ?: "Файл"
        title = name
        actionBar?.setDisplayHomeAsUpEnabled(true)
        val prefs = getSharedPreferences("viewer", Context.MODE_PRIVATE)
        wrap = prefs.getBoolean("wrap", true)
        fontSp = prefs.getFloat("font", 13f)

        frame = FrameLayout(this)
        progress = ProgressBar(this)
        frame.addView(progress, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        text = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp)
            setTextIsSelectable(true)
            val p = (8 * resources.displayMetrics.density).toInt()
            setPadding(p, p, p, p)
        }
        setContentView(frame)

        Thread {
            val res = runCatching {
                contentResolver.openInputStream(uri)!!.use { input ->
                    val buf = java.io.ByteArrayOutputStream()
                    val b = ByteArray(64 * 1024)
                    while (buf.size() < LIMIT) {
                        val r = input.read(b, 0, minOf(b.size, LIMIT - buf.size()))
                        if (r < 0) break
                        buf.write(b, 0, r)
                    }
                    val more = input.read() >= 0
                    buf.toByteArray() to more
                }
            }
            main.post {
                if (isDestroyed) return@post
                progress.visibility = View.GONE
                res.fold({ (bytes, more) ->
                    raw = bytes
                    truncated = more
                    charset = detect(bytes)
                    render()
                }, {
                    AlertDialog.Builder(this).setTitle("Не удалось открыть").setMessage(it.message ?: it.toString())
                        .setPositiveButton("OK") { _, _ -> finish() }.show()
                })
            }
        }.start()
    }

    private fun render() {
        var s = decode(raw, charset)
        if (truncated) s += "\n\n——— Показаны первые ${LIMIT / 1024 / 1024} МБ файла ———"
        text.text = s
        (text.parent as? android.view.ViewGroup)?.removeView(text)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        if (wrap) {
            scroll.addView(text, FrameLayout.LayoutParams(-1, -2))
        } else {
            val h = HorizontalScrollView(this)
            h.addView(text, FrameLayout.LayoutParams(-2, -2))
            scroll.addView(h, FrameLayout.LayoutParams(-1, -2))
        }
        text.setHorizontallyScrolling(!wrap)
        if (frame.childCount > 1) frame.removeViewAt(1)
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        actionBar?.subtitle = "${charset.displayName()} · ${MainActivity.fmtSize(raw.size.toLong())}${if (truncated) "+" else ""}"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Перенос строк").setCheckable(true).isChecked = wrap
        menu.add(0, 2, 0, "Крупнее")
        menu.add(0, 3, 0, "Мельче")
        menu.add(0, 4, 0, "Кодировка…")
        menu.add(0, 5, 0, "Открыть с помощью…")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val prefs = getSharedPreferences("viewer", Context.MODE_PRIVATE).edit()
        when (item.itemId) {
            android.R.id.home -> finish()
            1 -> { wrap = !wrap; item.isChecked = wrap; prefs.putBoolean("wrap", wrap).apply(); render() }
            2 -> { fontSp = minOf(fontSp + 1, 30f); text.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp); prefs.putFloat("font", fontSp).apply() }
            3 -> { fontSp = maxOf(fontSp - 1, 7f); text.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp); prefs.putFloat("font", fontSp).apply() }
            4 -> {
                val names = CHARSETS.filter { Charset.isSupported(it) }
                AlertDialog.Builder(this).setTitle("Кодировка").setItems(names.toTypedArray()) { _, w ->
                    charset = Charset.forName(names[w]); render()
                }.show()
            }
            5 -> Opener.openWith(this, uri, name)
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    companion object {
        private const val EXTRA_NAME = "name"
        private const val LIMIT = 2 * 1024 * 1024
        private val CHARSETS = listOf("UTF-8", "windows-1251", "IBM866", "KOI8-R", "UTF-16LE", "UTF-16BE", "ISO-8859-1")

        fun start(a: Activity, uri: Uri, name: String) {
            a.startActivity(Intent(a, TextViewerActivity::class.java).setData(uri).putExtra(EXTRA_NAME, name)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }

        fun detect(b: ByteArray): Charset {
            if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) return Charsets.UTF_8
            if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return Charsets.UTF_16LE
            if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return Charsets.UTF_16BE
            // Strict UTF-8 check (allow a cut multibyte char at the very end)
            val dec = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
            val r = dec.decode(ByteBuffer.wrap(b), java.nio.CharBuffer.allocate(b.size + 16), false)
            if (!r.isError) return Charsets.UTF_8
            return if (Charset.isSupported("windows-1251")) Charset.forName("windows-1251") else Charsets.ISO_8859_1
        }

        fun decode(b: ByteArray, cs: Charset): String {
            var s = String(b, cs)
            if (s.isNotEmpty() && s[0] == '﻿') s = s.substring(1)
            return s
        }
    }
}
