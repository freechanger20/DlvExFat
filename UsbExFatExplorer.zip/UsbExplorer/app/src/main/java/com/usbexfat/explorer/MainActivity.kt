package com.usbexfat.explorer

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.DocumentsContract
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.usbexfat.explorer.fs.ByteDevice
import com.usbexfat.explorer.fs.FileSystem
import com.usbexfat.explorer.fs.FsEntry
import com.usbexfat.explorer.fs.Partition
import com.usbexfat.explorer.fs.Partitions
import com.usbexfat.explorer.fs.mountPartition
import com.usbexfat.explorer.usb.UsbMassStorage
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private enum class Mode { DEVICES, PARTITIONS, BROWSE }

    private class Row(val icon: String, val title: String, val sub: String, val enabled: Boolean, val payload: Any?)

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var usb: UsbManager

    private var mode = Mode.DEVICES
    private var device: UsbDevice? = null
    private var storage: UsbMassStorage? = null
    private var bdev: ByteDevice? = null
    private var partitions: List<Partition> = emptyList()
    private var fs: FileSystem? = null
    private var fsTitle = ""
    private val stack = ArrayList<FsEntry>()
    private val scrollPos = ArrayList<Int>()
    private var rows: List<Row> = emptyList()

    private var pendingPermission: UsbDevice? = null
    private var pendingSave: FsEntry? = null
    private var pendingFolder: FsEntry? = null

    private lateinit var pathView: TextView
    private lateinit var busy: ProgressBar
    private lateinit var list: ListView
    private lateinit var emptyView: TextView
    private val adapter = RowAdapter()
    private val dateFmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        buildUi()
        val f = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else @Suppress("UnspecifiedRegisterReceiverFlag") registerReceiver(receiver, f)
        showDevices()
        handleAttachIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAttachIntent(intent)
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        val s = storage
        storage = null
        io.execute { s?.close() }
        io.shutdown()
        super.onDestroy()
    }

    private fun handleAttachIntent(intent: Intent?) {
        if (intent?.action != UsbManager.ACTION_USB_DEVICE_ATTACHED) return
        val d = usbDeviceExtra(intent) ?: return
        if (storage == null && UsbMassStorage.isMassStorage(d)) connect(d)
    }

    @Suppress("DEPRECATION")
    private fun usbDeviceExtra(intent: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        else intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_PERMISSION -> {
                    val d = pendingPermission ?: return
                    pendingPermission = null
                    if (usb.hasPermission(d)) connect(d) else toast("Доступ к накопителю не разрешён")
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> if (mode == Mode.DEVICES) showDevices()
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val d = usbDeviceExtra(intent)
                    if (d != null && d.deviceName == device?.deviceName) {
                        toast("Накопитель отключён")
                        disconnect()
                    } else if (mode == Mode.DEVICES) showDevices()
                }
            }
        }
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pathView = TextView(this).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            ellipsize = TextUtils.TruncateAt.START
            isSingleLine = true
            setBackgroundColor(0x22808080)
        }
        busy = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.INVISIBLE
        }
        list = ListView(this).apply {
            adapter = this@MainActivity.adapter
            onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ -> onRowClick(rows[pos]) }
            onItemLongClickListener = AdapterView.OnItemLongClickListener { _, _, pos, _ -> onRowLongClick(rows[pos]); true }
        }
        emptyView = TextView(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            textSize = 15f
            visibility = View.GONE
        }
        root.addView(pathView, LinearLayout.LayoutParams(-1, -2))
        root.addView(busy, LinearLayout.LayoutParams(-1, dp(4)))
        root.addView(emptyView, LinearLayout.LayoutParams(-1, -2))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun isEnabled(position: Int) = rows[position].enabled

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(10))
                addView(TextView(context).apply { textSize = 26f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(44), -2))
                val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
                col.addView(TextView(context).apply { textSize = 16f })
                col.addView(TextView(context).apply { textSize = 13f; alpha = 0.65f })
                addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            }
            val r = rows[position]
            val icon = v.getChildAt(0) as TextView
            val col = v.getChildAt(1) as LinearLayout
            icon.text = r.icon
            (col.getChildAt(0) as TextView).text = r.title
            (col.getChildAt(1) as TextView).apply { text = r.sub; visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE }
            v.alpha = if (r.enabled) 1f else 0.45f
            return v
        }
    }

    private fun setRows(newRows: List<Row>, path: String, empty: String, selection: Int = 0) {
        rows = newRows
        pathView.text = path
        adapter.notifyDataSetChanged()
        emptyView.text = empty
        emptyView.visibility = if (newRows.isEmpty()) View.VISIBLE else View.GONE
        list.setSelection(selection)
        invalidateOptionsMenu()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun error(title: String, e: Throwable) {
        AlertDialog.Builder(this).setTitle(title).setMessage(e.message ?: e.toString())
            .setPositiveButton("OK", null).show()
    }

    /** Runs [work] on the USB thread, then [done] on the UI thread. */
    private fun <T> bg(work: () -> T, done: (T) -> Unit, fail: (Throwable) -> Unit = { error("Ошибка", it) }) {
        busy.visibility = View.VISIBLE
        io.execute {
            val res = runCatching(work)
            main.post {
                if (isDestroyed) return@post
                busy.visibility = View.INVISIBLE
                res.fold(done, fail)
            }
        }
    }

    // ---------------------------------------------------------------- devices

    private fun showDevices() {
        mode = Mode.DEVICES
        val devs = usb.deviceList.values.filter { UsbMassStorage.isMassStorage(it) }
        setRows(devs.map { d ->
            val name = listOfNotNull(d.manufacturerName, d.productName).joinToString(" ").ifBlank { "USB-накопитель" }
            Row("🔌", name, "VID %04X · PID %04X".format(d.vendorId, d.productId), true, d)
        }, "USB-накопители",
            "Накопитель не найден.\n\nПодключите флешку через OTG-переходник. Если телефон не реагирует — проверьте, что в настройках включён OTG (на некоторых моделях он выключается сам через 10 минут).")
        title = applicationInfo.loadLabel(packageManager)
        actionBar?.setDisplayHomeAsUpEnabled(false)
    }

    private fun connect(d: UsbDevice) {
        if (!usb.hasPermission(d)) {
            pendingPermission = d
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION_PERMISSION).setPackage(packageName), flags)
            usb.requestPermission(d, pi)
            return
        }
        bg({
            val ms = UsbMassStorage.open(usb, d)
            val bd = ByteDevice(ms)
            val parts = try { Partitions.scan(bd) } catch (e: Exception) { ms.close(); throw e }
            Triple(ms, bd, parts)
        }, { (ms, bd, parts) ->
            device = d
            storage = ms
            bdev = bd
            partitions = parts
            showPartitions()
            // Single supported partition → open it right away
            val ok = parts.filter { it.fsType.supported }
            if (parts.size == 1 && ok.size == 1) openPartition(ok[0])
        }, { error("Не удалось открыть накопитель", it) })
    }

    private fun disconnect() {
        val s = storage
        storage = null; bdev = null; fs = null; device = null
        stack.clear(); partitions = emptyList()
        io.execute { s?.close() }
        showDevices()
    }

    // ---------------------------------------------------------------- partitions

    private fun showPartitions() {
        mode = Mode.PARTITIONS
        val ms = storage ?: return showDevices()
        val name = listOf(ms.vendor, ms.product).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "USB-накопитель" }
        title = name
        actionBar?.setDisplayHomeAsUpEnabled(true)
        setRows(partitions.map { p ->
            val label = p.label.ifBlank { p.gptName }
            val t = buildString {
                append("Раздел ${p.index}: ${p.fsType.title}")
                if (label.isNotBlank()) append(" «$label»")
            }
            val sub = buildString {
                append(fmtSize(p.length)); append(" · "); append(p.scheme)
                if (!p.fsType.supported) append(" · не поддерживается")
            }
            Row(if (p.fsType.supported) "💾" else "🚫", t, sub, p.fsType.supported, p)
        }, "$name · ${fmtSize(ms.blockCount * ms.blockSize)} · сектор ${ms.blockSize} Б",
            "Разделы не найдены. Возможно, накопитель не размечен.")
    }

    private fun openPartition(p: Partition) {
        val bd = bdev ?: return
        bg({ mountPartition(bd, p) }, { f ->
            fs = f
            fsTitle = f.label.ifBlank { "Раздел ${p.index}" }
            stack.clear(); scrollPos.clear()
            stack += f.root
            loadDir()
        }, { error("Не удалось открыть раздел", it) })
    }

    // ---------------------------------------------------------------- browsing

    private fun pathString(): String =
        "$fsTitle:/" + stack.drop(1).joinToString("/") { it.name } + if (stack.size > 1) "/" else ""

    private fun loadDir(selection: Int = 0) {
        val f = fs ?: return
        val dir = stack.last()
        bg({
            f.list(dir).sortedWith(compareBy<FsEntry>({ !it.isDir }, { it.name.lowercase() }))
        }, { entries ->
            mode = Mode.BROWSE
            title = fsTitle
            actionBar?.setDisplayHomeAsUpEnabled(true)
            setRows(entries.map { e ->
                val date = if (e.mtime > 0) dateFmt.format(Date(e.mtime)) else ""
                val sub = if (e.isDir) date else listOf(fmtSize(e.size), date).filter { it.isNotEmpty() }.joinToString(" · ")
                Row(if (e.isDir) "📁" else iconFor(e.name), e.name, sub, true, e)
            }, pathString(), "Папка пуста", selection)
        })
    }

    private fun onRowClick(r: Row) {
        when (val p = r.payload) {
            is UsbDevice -> connect(p)
            is Partition -> openPartition(p)
            is FsEntry -> if (p.isDir) {
                scrollPos += list.firstVisiblePosition
                stack += p
                loadDir()
            } else fileMenu(p)
        }
    }

    private fun onRowLongClick(r: Row) {
        val e = r.payload as? FsEntry ?: return
        if (e.isDir) {
            AlertDialog.Builder(this).setTitle(e.name)
                .setItems(arrayOf("Открыть", "Скопировать папку на телефон…")) { _, w ->
                    if (w == 0) onRowClick(r) else pickFolderTarget(e)
                }.show()
        } else fileMenu(e)
    }

    private fun fileMenu(e: FsEntry) {
        AlertDialog.Builder(this)
            .setTitle(e.name)
            .setMessage(fmtSize(e.size) + if (e.mtime > 0) "\n" + dateFmt.format(Date(e.mtime)) else "")
            .setItems(arrayOf("Открыть в приложении", "Сохранить на телефон…", "Поделиться")) { _, w ->
                when (w) {
                    0 -> openExternally(e, share = false)
                    1 -> saveFile(e)
                    2 -> openExternally(e, share = true)
                }
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (mode) {
            Mode.BROWSE -> if (stack.size > 1) {
                stack.removeAt(stack.size - 1)
                loadDir(scrollPos.removeLastOrNull() ?: 0)
            } else if (partitions.size > 1) showPartitions() else disconnect()
            Mode.PARTITIONS -> disconnect()
            Mode.DEVICES -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (mode == Mode.BROWSE) {
            menu.add(0, M_COPY_DIR, 0, "Скопировать эту папку…")
        }
        if (mode != Mode.DEVICES) menu.add(0, M_EJECT, 0, "Отключить накопитель")
        menu.add(0, M_REFRESH, 0, "Обновить").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        return true
    }

    @Suppress("DEPRECATION")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> onBackPressed()
            M_REFRESH -> when (mode) {
                Mode.DEVICES -> showDevices()
                Mode.PARTITIONS -> showPartitions()
                Mode.BROWSE -> { bdev?.clearCache(); loadDir(list.firstVisiblePosition) }
            }
            M_COPY_DIR -> pickFolderTarget(stack.last())
            M_EJECT -> disconnect()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------------------------------------------------------- copying

    private fun saveFile(e: FsEntry) {
        pendingSave = e
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType(mimeOf(e.name)).putExtra(Intent.EXTRA_TITLE, e.name)
        startActivityForResult(i, REQ_SAVE)
    }

    private fun pickFolderTarget(dir: FsEntry) {
        pendingFolder = dir
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_SAVE -> pendingSave?.let { e ->
                runCopy("Сохранение", e.size) { p ->
                    val out = contentResolver.openOutputStream(uri, "w") ?: throw java.io.IOException("Не удалось создать файл")
                    out.use { o -> fs!!.open(e).use { copy(it, o, p) } }
                    "Сохранено: ${e.name}"
                }
            }
            REQ_TREE -> pendingFolder?.let { d -> copyFolder(d, uri) }
        }
    }

    private fun copyFolder(dir: FsEntry, tree: Uri) {
        val f = fs ?: return
        val rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val dirName = if (dir === f.root) fsTitle else dir.name
        runCopy("Копирование папки", -1) { p ->
            p.setTotal(totalSize(f, dir))
            val target = DocumentsContract.createDocument(contentResolver, rootDoc, DocumentsContract.Document.MIME_TYPE_DIR, safeName(dirName))
                ?: throw java.io.IOException("Не удалось создать папку")
            var files = 0
            fun walk(src: FsEntry, dst: Uri) {
                for (e in f.list(src)) {
                    if (p.cancelled) return
                    val name = safeName(e.name)
                    if (e.isDir) {
                        val nd = DocumentsContract.createDocument(contentResolver, dst, DocumentsContract.Document.MIME_TYPE_DIR, name)
                            ?: throw java.io.IOException("Не удалось создать папку $name")
                        walk(e, nd)
                    } else {
                        p.setFile(e.name)
                        val nf = DocumentsContract.createDocument(contentResolver, dst, mimeOf(e.name), name)
                            ?: throw java.io.IOException("Не удалось создать файл $name")
                        contentResolver.openOutputStream(nf, "w")!!.use { o -> f.open(e).use { copy(it, o, p) } }
                        files++
                    }
                }
            }
            walk(dir, target)
            "Скопировано файлов: $files"
        }
    }

    private fun totalSize(f: FileSystem, dir: FsEntry): Long =
        f.list(dir).sumOf { if (it.isDir) totalSize(f, it) else it.size }

    private fun safeName(n: String) = n.replace('/', '_').ifBlank { "_" }

    private fun openExternally(e: FsEntry, share: Boolean) {
        val f = fs ?: return
        val dir = CacheProvider.openDir(cacheDir)
        if (e.size > dir.usableSpace - 50L * 1024 * 1024) {
            toast("Недостаточно места во внутренней памяти — используйте «Сохранить на телефон…»")
            return
        }
        val name = safeName(e.name)
        runCopy("Подготовка файла", e.size) { p ->
            dir.listFiles()?.forEach { it.delete() }
            val tmp = File(dir, name)
            tmp.outputStream().use { o -> f.open(e).use { copy(it, o, p) } }
            if (p.cancelled) tmp.delete()
            null
        }.onSuccess = {
            val uri = CacheProvider.uriFor(name)
            val intent = if (share) Intent(Intent.ACTION_SEND).setType(mimeOf(name)).putExtra(Intent.EXTRA_STREAM, uri)
            else Intent(Intent.ACTION_VIEW).setDataAndType(uri, mimeOf(name))
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                startActivity(Intent.createChooser(intent, if (share) "Поделиться" else "Открыть с помощью"))
            } catch (ex: Exception) { toast("Нет приложения для этого типа файлов") }
        }
    }

    /** Progress dialog bound to a copy job. */
    private inner class Progress(titleText: String, total: Long) {
        @Volatile var cancelled = false
        @Volatile private var total = total
        @Volatile private var done = 0L
        @Volatile private var file = ""
        private val started = SystemClock.elapsedRealtime()
        private var lastUi = 0L
        var onSuccess: (() -> Unit)? = null

        private val text = TextView(this@MainActivity).apply { textSize = 14f }
        private val bar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        val dialog: AlertDialog = AlertDialog.Builder(this@MainActivity)
            .setTitle(titleText)
            .setView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(24), dp(12), dp(24), dp(4))
                addView(bar); addView(text)
            })
            .setCancelable(false)
            .setNegativeButton("Отмена") { _, _ -> cancelled = true }
            .create()

        fun setTotal(t: Long) { total = t; post(true) }
        fun setFile(n: String) { file = n; post(true) }
        fun add(n: Int) { done += n; post(false) }

        private fun post(force: Boolean) {
            val now = SystemClock.elapsedRealtime()
            if (!force && now - lastUi < 250) return
            lastUi = now
            main.post { render() }
        }

        fun render() {
            val secs = (SystemClock.elapsedRealtime() - started) / 1000.0
            val speed = if (secs > 0.5) done / secs else 0.0
            bar.isIndeterminate = total <= 0
            if (total > 0) bar.progress = (done * 1000 / total).toInt()
            text.text = buildString {
                if (file.isNotEmpty()) append(file).append('\n')
                append(fmtSize(done))
                if (total > 0) append(" из ").append(fmtSize(total))
                if (speed > 0) append(" · ").append(fmtSize(speed.toLong())).append("/с")
            }
        }
    }

    private fun copy(input: InputStream, out: OutputStream, p: Progress) {
        val buf = ByteArray(1024 * 1024)
        while (!p.cancelled) {
            val r = input.read(buf)
            if (r < 0) break
            out.write(buf, 0, r)
            p.add(r)
        }
    }

    private fun runCopy(title: String, total: Long, job: (Progress) -> String?): Progress {
        val p = Progress(title, total)
        p.dialog.show()
        p.render()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        io.execute {
            val res = runCatching { job(p) }
            main.post {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (isDestroyed) return@post
                p.dialog.dismiss()
                res.fold({ msg ->
                    if (p.cancelled) toast("Отменено")
                    else { msg?.let { toast(it) }; p.onSuccess?.invoke() }
                }, { error("Ошибка копирования", it) })
            }
        }
        return p
    }

    // ---------------------------------------------------------------- helpers

    private fun iconFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "iso", "img", "vhd", "vhdx", "wim", "esd" -> "💿"
        "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> "🖼️"
        "mp4", "mkv", "avi", "mov", "webm" -> "🎬"
        "mp3", "flac", "wav", "ogg", "m4a", "opus" -> "🎵"
        "zip", "rar", "7z", "tar", "gz", "xz", "zst" -> "🗜️"
        "apk" -> "📦"
        "pdf" -> "📕"
        "txt", "cfg", "conf", "ini", "log", "md", "json", "xml" -> "📝"
        "efi", "exe", "bin", "sys" -> "⚙️"
        else -> "📄"
    }

    companion object {
        private const val ACTION_PERMISSION = "com.usbexfat.explorer.USB_PERMISSION"
        private const val REQ_SAVE = 1
        private const val REQ_TREE = 2
        private const val M_REFRESH = 1
        private const val M_COPY_DIR = 2
        private const val M_EJECT = 3

        fun fmtSize(b: Long): String {
            if (b < 1024) return "$b Б"
            val u = arrayOf("КБ", "МБ", "ГБ", "ТБ")
            var v = b / 1024.0
            var i = 0
            while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
            return String.format(Locale.getDefault(), if (v < 10) "%.2f %s" else if (v < 100) "%.1f %s" else "%.0f %s", v, u[i])
        }
    }
}
