package com.usbexfat.explorer

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.text.TextUtils
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import com.usbexfat.explorer.fs.ByteDevice
import com.usbexfat.explorer.fs.FileSystem
import com.usbexfat.explorer.fs.FsEntry
import com.usbexfat.explorer.fs.Partition
import com.usbexfat.explorer.fs.Partitions
import com.usbexfat.explorer.fs.mountPartition
import com.usbexfat.explorer.usb.UsbMassStorage
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private enum class Mode { DEVICES, PARTITIONS, BROWSE }

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var usb: UsbManager

    private var mode = Mode.DEVICES
    private var device: UsbDevice? = null
    private var storage: UsbMassStorage? = null
    private var bdev: ByteDevice? = null
    private var partitions: List<Partition> = emptyList()
    private var fs: FileSystem? = null
    private var fsTitle = ""
    private val stack = ArrayList<FsEntry>()
    private val scrollPos = ArrayList<Int>()

    private var pendingPermission: UsbDevice? = null
    private var pendingSave: FsEntry? = null
    private var pendingFolder: FsEntry? = null

    private lateinit var pathView: TextView
    private lateinit var busy: ProgressBar
    private lateinit var list: ListView
    private lateinit var emptyView: TextView
    private val adapter by lazy { RowsAdapter(this) }
    private val dateFmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        buildUi()
        val f = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else @Suppress("UnspecifiedRegisterReceiverFlag") registerReceiver(receiver, f)
        showDevices()
        handleAttachIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAttachIntent(intent)
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        FilesProvider.clearUsb()
        val s = storage
        storage = null
        io.execute { s?.close() }
        io.shutdown()
        super.onDestroy()
    }

    private fun handleAttachIntent(intent: Intent?) {
        if (intent?.action != UsbManager.ACTION_USB_DEVICE_ATTACHED) return
        val d = usbDeviceExtra(intent) ?: return
        if (storage == null && UsbMassStorage.isMassStorage(d)) connect(d)
    }

    @Suppress("DEPRECATION")
    private fun usbDeviceExtra(intent: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        else intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_PERMISSION -> {
                    val d = pendingPermission ?: return
                    pendingPermission = null
                    if (usb.hasPermission(d)) connect(d) else toast("Доступ к накопителю не разрешён")
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> if (mode == Mode.DEVICES) showDevices()
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val d = usbDeviceExtra(intent)
                    if (d != null && d.deviceName == device?.deviceName) {
                        toast("Накопитель отключён")
                        disconnect()
                    } else if (mode == Mode.DEVICES) showDevices()
                }
            }
        }
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pathView = TextView(this).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            ellipsize = TextUtils.TruncateAt.START
            isSingleLine = true
            setBackgroundColor(0x22808080)
        }
        busy = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.INVISIBLE
        }
        list = ListView(this).apply {
            adapter = this@MainActivity.adapter
            onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ -> onRowClick(this@MainActivity.adapter.rows[pos]) }
            onItemLongClickListener = AdapterView.OnItemLongClickListener { _, _, pos, _ -> onRowLongClick(this@MainActivity.adapter.rows[pos]); true }
        }
        emptyView = TextView(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            textSize = 15f
            visibility = View.GONE
        }
        root.addView(pathView, LinearLayout.LayoutParams(-1, -2))
        root.addView(busy, LinearLayout.LayoutParams(-1, dp(4)))
        root.addView(emptyView, LinearLayout.LayoutParams(-1, -2))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun setRows(newRows: List<Row>, path: String, empty: String, selection: Int = 0) {
        adapter.rows = newRows
        pathView.text = path
        emptyView.text = empty
        emptyView.visibility = if (newRows.isEmpty()) View.VISIBLE else View.GONE
        list.setSelection(selection)
        invalidateOptionsMenu()
    }

    /** Runs [work] on the USB thread, then [done] on the UI thread. */
    private fun <T> bg(work: () -> T, done: (T) -> Unit, fail: (Throwable) -> Unit = { showError("Ошибка", it) }) {
        busy.visibility = View.VISIBLE
        io.execute {
            val res = runCatching(work)
            main.post {
                if (isDestroyed) return@post
                busy.visibility = View.INVISIBLE
                res.fold(done, fail)
            }
        }
    }

    // ---------------------------------------------------------------- devices

    private fun showDevices() {
        mode = Mode.DEVICES
        val devs = usb.deviceList.values.filter { UsbMassStorage.isMassStorage(it) }
        setRows(devs.map { d ->
            val name = listOfNotNull(d.manufacturerName, d.productName).joinToString(" ").ifBlank { "USB-накопитель" }
            Row("🔌", name, "VID %04X · PID %04X".format(d.vendorId, d.productId), true, d)
        }, "USB-накопители",
            "Накопитель не найден.\n\nПодключите флешку через OTG-переходник. Если телефон не реагирует — проверьте, что в настройках включён OTG (на некоторых моделях он выключается сам через 10 минут).")
        title = applicationInfo.loadLabel(packageManager)
        actionBar?.setDisplayHomeAsUpEnabled(false)
    }

    private fun connect(d: UsbDevice) {
        if (!usb.hasPermission(d)) {
            pendingPermission = d
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION_PERMISSION).setPackage(packageName), flags)
            usb.requestPermission(d, pi)
            return
        }
        bg({
            val ms = UsbMassStorage.open(usb, d)
            val bd = ByteDevice(ms)
            val parts = try { Partitions.scan(bd) } catch (e: Exception) { ms.close(); throw e }
            Triple(ms, bd, parts)
        }, { (ms, bd, parts) ->
            device = d
            storage = ms
            bdev = bd
            partitions = parts
            showPartitions()
            val ok = parts.filter { it.fsType.supported }
            if (parts.size == 1 && ok.size == 1) openPartition(ok[0])
        }, { showError("Не удалось открыть накопитель", it) })
    }

    private fun disconnect() {
        val s = storage
        storage = null; bdev = null; fs = null; device = null
        stack.clear(); partitions = emptyList()
        FilesProvider.clearUsb()
        io.execute { s?.close() }
        showDevices()
    }

    // ---------------------------------------------------------------- partitions

    private fun showPartitions() {
        mode = Mode.PARTITIONS
        val ms = storage ?: return showDevices()
        val name = listOf(ms.vendor, ms.product).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "USB-накопитель" }
        title = name
        actionBar?.setDisplayHomeAsUpEnabled(true)
        setRows(partitions.map { p ->
            val label = p.label.ifBlank { p.gptName }
            val t = buildString {
                append("Раздел ${p.index}: ${p.fsType.title}")
                if (label.isNotBlank()) append(" «$label»")
            }
            val sub = buildString {
                append(fmtSize(p.length)); append(" · "); append(p.scheme)
                if (!p.fsType.supported) append(" · не поддерживается")
            }
            Row(if (p.fsType.supported) "💾" else "🚫", t, sub, p.fsType.supported, p)
        }, "$name · ${fmtSize(ms.blockCount * ms.blockSize)} · сектор ${ms.blockSize} Б",
            "Разделы не найдены. Возможно, накопитель не размечен.")
    }

    private fun openPartition(p: Partition) {
        val bd = bdev ?: return
        bg({ mountPartition(bd, p) }, { f ->
            fs = f
            fsTitle = f.label.ifBlank { "Раздел ${p.index}" }
            stack.clear(); scrollPos.clear()
            stack += f.root
            loadDir()
        }, { showError("Не удалось открыть раздел", it) })
    }

    // ---------------------------------------------------------------- browsing

    private fun pathString(): String =
        "$fsTitle:/" + stack.drop(1).joinToString("/") { it.name } + if (stack.size > 1) "/" else ""

    private fun loadDir(selection: Int = 0) {
        val f = fs ?: return
        val dir = stack.last()
        bg({
            f.list(dir).sortedWith(compareBy<FsEntry>({ !it.isDir }, { it.name.lowercase() }))
        }, { entries ->
            mode = Mode.BROWSE
            title = fsTitle
            actionBar?.setDisplayHomeAsUpEnabled(true)
            setRows(entries.map { e ->
                val date = if (e.mtime > 0) dateFmt.format(Date(e.mtime)) else ""
                val sub = if (e.isDir) date else listOf(fmtSize(e.size), date).filter { it.isNotEmpty() }.joinToString(" · ")
                Row(if (e.isDir) "📁" else iconFor(e.name), e.name, sub, true, e)
            }, pathString(), "Папка пуста", selection)
        })
    }

    private fun onRowClick(r: Row) {
        when (val p = r.payload) {
            is UsbDevice -> connect(p)
            is Partition -> openPartition(p)
            is FsEntry -> if (p.isDir) {
                scrollPos += list.firstVisiblePosition
                stack += p
                loadDir()
            } else withUri(p) { Opener.open(this, it, p.name) }
        }
    }

    private fun onRowLongClick(r: Row) {
        val e = r.payload as? FsEntry ?: return
        if (e.isDir) {
            AlertDialog.Builder(this).setTitle(e.name)
                .setItems(arrayOf("Открыть", "Скопировать папку на телефон…")) { _, w ->
                    if (w == 0) onRowClick(r) else pickFolderTarget(e)
                }.show()
        } else fileMenu(e)
    }

    private fun fileMenu(e: FsEntry) {
        val items = arrayListOf(
            "Открыть" to { withUri(e) { Opener.open(this, it, e.name) } },
            "Открыть с помощью…" to { withUri(e) { Opener.openWith(this, it, e.name) } },
            "Просмотреть как текст" to { withUri(e) { TextViewerActivity.start(this, it, e.name) } },
        )
        if (isZipFile(e.name)) items += "Открыть как ZIP-архив" to { withUri(e) { ArchiveActivity.start(this, it, e.name) } }
        items += "Сохранить на телефон…" to { saveFile(e) }
        items += "Поделиться" to { withUri(e) { Opener.share(this, it, e.name) } }
        AlertDialog.Builder(this)
            .setTitle(e.name)
            .setMessage(fmtSize(e.size) + (if (e.mtime > 0) " · " + dateFmt.format(Date(e.mtime)) else "") + "\n" + mimeOf(e.name))
            .setItems(items.map { it.first }.toTypedArray()) { _, w -> items[w].second() }
            .show()
    }

    /**
     * Gives a content URI for a file on the drive. Android 8+: streamed live from USB with seeking,
     * so even huge videos open instantly. Older Android: copied to the app cache first.
     */
    private fun withUri(e: FsEntry, then: (Uri) -> Unit) {
        val f = fs ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            then(FilesProvider.usbUri(f, e))
            return
        }
        val dir = FilesProvider.cacheDir(this)
        if (e.size > dir.usableSpace - 50L * 1024 * 1024) {
            toast("Недостаточно места во внутренней памяти — используйте «Сохранить на телефон…»")
            return
        }
        val out = File(dir, safeName(e.name))
        runJob("Подготовка файла", e.size, io, { p ->
            cleanOpenCache(this)
            out.outputStream().use { o -> f.open(e).use { copyWithProgress(it, o, p) } }
            if (p.cancelled) out.delete()
        }) { then(FilesProvider.cacheUri(out.name)) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (mode) {
            Mode.BROWSE -> if (stack.size > 1) {
                stack.removeAt(stack.size - 1)
                loadDir(scrollPos.removeLastOrNull() ?: 0)
            } else if (partitions.size > 1) showPartitions() else disconnect()
            Mode.PARTITIONS -> disconnect()
            Mode.DEVICES -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (mode == Mode.BROWSE) menu.add(0, M_COPY_DIR, 0, "Скопировать эту папку…")
        if (mode != Mode.DEVICES) menu.add(0, M_EJECT, 0, "Отключить накопитель")
        menu.add(0, M_REFRESH, 0, "Обновить").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        return true
    }

    @Suppress("DEPRECATION")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> onBackPressed()
            M_REFRESH -> when (mode) {
                Mode.DEVICES -> showDevices()
                Mode.PARTITIONS -> showPartitions()
                Mode.BROWSE -> { bdev?.clearCache(); loadDir(list.firstVisiblePosition) }
            }
            M_COPY_DIR -> pickFolderTarget(stack.last())
            M_EJECT -> disconnect()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------------------------------------------------------- copying to the phone

    private fun saveFile(e: FsEntry) {
        pendingSave = e
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType(mimeOf(e.name)).putExtra(Intent.EXTRA_TITLE, e.name)
        startActivityForResult(i, REQ_SAVE)
    }

    private fun pickFolderTarget(dir: FsEntry) {
        pendingFolder = dir
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        val f = fs ?: return
        when (requestCode) {
            REQ_SAVE -> pendingSave?.let { e ->
                runJob("Сохранение", e.size, io, { p ->
                    val out = contentResolver.openOutputStream(uri, "w") ?: throw IOException("Не удалось создать файл")
                    out.use { o -> f.open(e).use { copyWithProgress(it, o, p) } }
                }) { toast("Сохранено: ${e.name}") }
            }
            REQ_TREE -> pendingFolder?.let { d -> copyFolder(f, d, uri) }
        }
    }

    private fun copyFolder(f: FileSystem, dir: FsEntry, tree: Uri) {
        val rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val dirName = if (dir === f.root) fsTitle else dir.name
        runJob("Копирование папки", -1, io, { p ->
            p.setTotal(totalSize(f, dir))
            val target = DocumentsContract.createDocument(contentResolver, rootDoc, DocumentsContract.Document.MIME_TYPE_DIR, safeName(dirName))
                ?: throw IOException("Не удалось создать папку")
            var files = 0
            fun walk(src: FsEntry, dst: Uri) {
                for (e in f.list(src)) {
                    if (p.cancelled) return
                    val name = safeName(e.name)
                    if (e.isDir) {
                        val nd = DocumentsContract.createDocument(contentResolver, dst, DocumentsContract.Document.MIME_TYPE_DIR, name)
                            ?: throw IOException("Не удалось создать папку $name")
                        walk(e, nd)
                    } else {
                        p.setFile(e.name)
                        val nf = DocumentsContract.createDocument(contentResolver, dst, mimeOf(e.name), name)
                            ?: throw IOException("Не удалось создать файл $name")
                        contentResolver.openOutputStream(nf, "w")!!.use { o -> f.open(e).use { copyWithProgress(it, o, p) } }
                        files++
                    }
                }
            }
            walk(dir, target)
            files
        }) { toast("Скопировано файлов: $it") }
    }

    private fun totalSize(f: FileSystem, dir: FsEntry): Long =
        f.list(dir).sumOf { if (it.isDir) totalSize(f, it) else it.size }

    companion object {
        private const val ACTION_PERMISSION = "com.usbexfat.explorer.USB_PERMISSION"
        private const val REQ_SAVE = 1
        private const val REQ_TREE = 2
        private const val M_REFRESH = 1
        private const val M_COPY_DIR = 2
        private const val M_EJECT = 3

        fun fmtSize(b: Long): String = com.usbexfat.explorer.fmtSize(b)
    }
}
