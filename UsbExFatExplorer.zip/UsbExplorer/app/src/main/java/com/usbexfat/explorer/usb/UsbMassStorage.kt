package com.usbexfat.explorer.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import com.usbexfat.explorer.fs.BlockDevice
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * USB Mass Storage, Bulk-Only Transport + SCSI transparent command set.
 * Talks to the drive directly through the Android USB Host API,
 * so it does not depend on what filesystems the phone's kernel supports.
 */
class UsbMassStorage private constructor(
    private val conn: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val epIn: UsbEndpoint,
    private val epOut: UsbEndpoint,
) : BlockDevice {

    override var blockSize = 512
        private set
    override var blockCount = 0L
        private set
    /** Callers may ask for big reads; they are split internally by [maxBytes]. */
    override val maxBlocksPerRead: Int get() = maxOf(1, 1024 * 1024 / blockSize)

    /** Current max bytes per SCSI READ. Lowered automatically if the drive chokes. */
    @Volatile var maxBytes = 64 * 1024
        private set

    var vendor = ""
        private set
    var product = ""
        private set

    private var tag = 1
    private var lastGot = 0
    // 16 KiB per USB request works on every phone/host controller
    private val transferChunk = 16 * 1024
    private val tmp = ByteArray(transferChunk)

    private fun init() {
        val inq = ByteArray(36)
        if (scsi(byteArrayOf(0x12, 0, 0, 0, 36, 0), inq, 36) == 0) {
            vendor = String(inq, 8, 8, Charsets.US_ASCII).trim()
            product = String(inq, 16, 16, Charsets.US_ASCII).trim()
        }
        // Wait for the unit to become ready (some drives need a few tries)
        var ready = false
        for (i in 0 until 20) {
            if (scsi(byteArrayOf(0, 0, 0, 0, 0, 0), null, 0) == 0) { ready = true; break }
            requestSense()
            Thread.sleep(150)
        }
        if (!ready) throw IOException("Накопитель не готов (TEST UNIT READY)")
        readCapacity()
    }

    private fun readCapacity() {
        val cap = ByteArray(8)
        var st = -1
        for (i in 0 until 3) {
            st = scsi(byteArrayOf(0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0), cap, 8)
            if (st == 0) break
            requestSense()
        }
        if (st != 0) throw IOException("Не удалось прочитать ёмкость накопителя")
        val bb = ByteBuffer.wrap(cap).order(ByteOrder.BIG_ENDIAN)
        var last = bb.getInt(0).toLong() and 0xFFFFFFFFL
        blockSize = bb.getInt(4)
        if (last == 0xFFFFFFFFL) {
            val c16 = ByteArray(32)
            val cdb = ByteArray(16)
            cdb[0] = 0x9E.toByte(); cdb[1] = 0x10; cdb[13] = 32
            if (scsi(cdb, c16, 32) != 0) throw IOException("READ CAPACITY(16) не поддерживается")
            val b16 = ByteBuffer.wrap(c16).order(ByteOrder.BIG_ENDIAN)
            last = b16.getLong(0)
            blockSize = b16.getInt(8)
        }
        if (blockSize !in intArrayOf(512, 1024, 2048, 4096)) throw IOException("Неподдерживаемый размер сектора: $blockSize")
        blockCount = last + 1
    }

    private fun requestSense() {
        val s = ByteArray(18)
        try { scsi(byteArrayOf(0x03, 0, 0, 0, 18, 0), s, 18) } catch (_: IOException) {}
    }

    @Synchronized
    override fun readBlocks(lba: Long, count: Int, buf: ByteArray, off: Int) {
        var l = lba
        var c = count
        var o = off
        while (c > 0) {
            val n = minOf(c, maxOf(1, maxBytes / blockSize))
            readOnce(l, n, buf, o)
            l += n; c -= n; o += n * blockSize
        }
    }

    private fun readOnce(lba: Long, count: Int, buf: ByteArray, off: Int) {
        var lastErr: IOException? = null
        var n = count
        var done = 0
        var attempts = 0
        while (done < count) {
            n = minOf(n, count - done, maxOf(1, maxBytes / blockSize))
            try {
                readCmd(lba + done, n, buf, off + done * blockSize)
                done += n
                attempts = 0
            } catch (e: IOException) {
                lastErr = e
                resetRecovery()
                // Drive or phone can't handle this transfer size → halve it
                if (maxBytes > blockSize) maxBytes = maxOf(blockSize, maxBytes / 2)
                if (++attempts > 6) throw lastErr
            }
        }
    }

    private fun readCmd(lba: Long, count: Int, buf: ByteArray, off: Int) {
        val len = count * blockSize
        val cdb: ByteArray
        if (lba + count <= 0xFFFFFFFFL) {
            cdb = ByteArray(10)
            cdb[0] = 0x28
            cdb[2] = (lba ushr 24).toByte(); cdb[3] = (lba ushr 16).toByte()
            cdb[4] = (lba ushr 8).toByte(); cdb[5] = lba.toByte()
            cdb[7] = (count ushr 8).toByte(); cdb[8] = count.toByte()
        } else {
            cdb = ByteArray(16)
            cdb[0] = 0x88.toByte()
            for (k in 0 until 8) cdb[2 + k] = (lba ushr (56 - 8 * k)).toByte()
            for (k in 0 until 4) cdb[10 + k] = (count ushr (24 - 8 * k)).toByte()
        }
        val st = scsi(cdb, buf, len, off)
        if (st != 0) { requestSense(); throw IOException("Ошибка чтения сектора $lba (статус $st)") }
        if (lastGot != len) throw IOException("USB: получено $lastGot из $len байт")
    }

    /** Runs one SCSI command. Returns CSW status (0 = OK). */
    private fun scsi(cdb: ByteArray, data: ByteArray?, dataLen: Int, dataOff: Int = 0): Int {
        val t = tag++
        val cbw = ByteBuffer.allocate(31).order(ByteOrder.LITTLE_ENDIAN)
        cbw.putInt(0x43425355).putInt(t).putInt(dataLen)
        cbw.put(if (dataLen > 0) 0x80.toByte() else 0).put(0).put(cdb.size.toByte())
        cbw.put(cdb)
        val cbwBytes = cbw.array()
        if (conn.bulkTransfer(epOut, cbwBytes, 31, TIMEOUT) != 31) {
            resetRecovery()
            throw IOException("USB: не удалось отправить команду")
        }
        var got = 0
        if (dataLen > 0 && data != null) {
            while (got < dataLen) {
                val want = minOf(transferChunk, dataLen - got)
                val r = conn.bulkTransfer(epIn, tmp, want, TIMEOUT)
                if (r < 0) {
                    resetRecovery()
                    throw IOException("USB: нет ответа от накопителя при передаче данных")
                }
                System.arraycopy(tmp, 0, data, dataOff + got, r)
                got += r
                if (r < want) break // short packet = end of data
            }
        }
        val csw = ByteArray(13)
        var r = conn.bulkTransfer(epIn, csw, 13, TIMEOUT)
        if (r != 13) {
            clearHalt(epIn)
            r = conn.bulkTransfer(epIn, csw, 13, TIMEOUT)
        }
        if (r != 13) { resetRecovery(); throw IOException("USB: нет ответа от накопителя") }
        val cb = ByteBuffer.wrap(csw).order(ByteOrder.LITTLE_ENDIAN)
        if (cb.getInt(0) != 0x53425355 || cb.getInt(4) != t) { resetRecovery(); throw IOException("USB: неверный ответ") }
        lastGot = got
        val status = csw[12].toInt() and 0xFF
        if (status == 2) { resetRecovery(); throw IOException("USB: phase error") }
        return status
    }

    private fun clearHalt(ep: UsbEndpoint) {
        conn.controlTransfer(0x02, 0x01, 0, ep.address, null, 0, TIMEOUT)
    }

    private fun resetRecovery() {
        conn.controlTransfer(0x21, 0xFF, 0, iface.id, null, 0, TIMEOUT)
        clearHalt(epIn)
        clearHalt(epOut)
    }

    override fun close() {
        try { conn.releaseInterface(iface) } catch (_: Exception) {}
        conn.close()
    }

    companion object {
        private const val TIMEOUT = 5000

        fun findInterface(device: UsbDevice): UsbInterface? {
            for (i in 0 until device.interfaceCount) {
                val itf = device.getInterface(i)
                if (itf.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE &&
                    itf.interfaceSubclass == 6 && itf.interfaceProtocol == 0x50) return itf
            }
            return null
        }

        fun isMassStorage(device: UsbDevice) = findInterface(device) != null

        @Throws(IOException::class)
        fun open(manager: UsbManager, device: UsbDevice): UsbMassStorage {
            val itf = findInterface(device) ?: throw IOException("Это не USB-накопитель")
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (i in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(i)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
            }
            if (inEp == null || outEp == null) throw IOException("Не найдены bulk-каналы")
            val conn = manager.openDevice(device) ?: throw IOException("Нет доступа к устройству")
            if (!conn.claimInterface(itf, true)) { conn.close(); throw IOException("Не удалось захватить интерфейс USB") }
            val ms = UsbMassStorage(conn, itf, inEp, outEp)
            try { ms.init() } catch (e: Exception) { ms.close(); throw e as? IOException ?: IOException(e.message, e) }
            return ms
        }
    }
}
