package com.usbexfat.explorer.fs

import java.io.IOException
import java.io.InputStream
import java.util.Calendar

/** Read-only FAT12/16/32 driver with long file names (VFAT). */
class FatFs(private val dev: ByteDevice, private val base: Long) : FileSystem {
    override val typeName: String
    override val label: String
    override val root: FsEntry

    private val bps: Int
    private val clusterSize: Long
    private val fatPos: Long
    private val rootDirPos: Long
    private val rootDirBytes: Int
    private val dataPos: Long
    private val clusterCount: Long
    private val bits: Int

    init {
        val b = dev.read(base, 512)
        val probe = probe(b) ?: throw IOException("Это не FAT")
        bps = b.u16(11)
        val spc = b.u8(13)
        val reserved = b.u16(14)
        val numFats = b.u8(16)
        val rootEnt = b.u16(17)
        val tot16 = b.u16(19)
        val fat16 = b.u16(22)
        val tot = if (tot16 != 0) tot16.toLong() else b.u32(32)
        val fatSz = if (fat16 != 0) fat16.toLong() else b.u32(36)
        rootDirBytes = rootEnt * 32
        val rootSectors = (rootDirBytes + bps - 1) / bps
        val dataSector = reserved + numFats * fatSz + rootSectors
        clusterCount = (tot - dataSector) / spc
        bits = when (probe.first) { FsType.FAT12 -> 12; FsType.FAT16 -> 16; else -> 32 }
        typeName = probe.first.title
        clusterSize = bps.toLong() * spc
        fatPos = base + reserved.toLong() * bps
        rootDirPos = base + (reserved + numFats * fatSz) * bps
        dataPos = base + dataSector * bps
        root = FsEntry("", true, 0, 0, if (bits == 32) b.u32(44) else 0)
        label = rootLabel() ?: probe.second
    }

    private fun clusterPos(c: Long) = dataPos + (c - 2) * clusterSize

    private fun valid(c: Long) = c >= 2 && c < clusterCount + 2

    private fun fatNext(c: Long): Long = when (bits) {
        12 -> {
            val v = dev.read(fatPos + c + c / 2, 2).u16(0)
            val x = if (c and 1L == 1L) v ushr 4 else v and 0xFFF
            if (x >= 0xFF7) -1 else x.toLong()
        }
        16 -> {
            val x = dev.read(fatPos + c * 2, 2).u16(0)
            if (x >= 0xFFF7) -1 else x.toLong()
        }
        else -> {
            val x = dev.read(fatPos + c * 4, 4).u32(0) and 0x0FFFFFFF
            if (x >= 0x0FFFFFF7) -1 else x
        }
    }

    private fun runs(first: Long, maxClusters: Long): List<Run> {
        if (!valid(first) || maxClusters == 0L) return emptyList()
        val out = ArrayList<Run>()
        var rf = first
        var rl = 1L
        var cur = first
        var total = 1L
        while (total < maxClusters) {
            val next = fatNext(cur)
            if (!valid(next)) break
            if (next == cur + 1) rl++ else { out += Run(rf, rl); rf = next; rl = 1 }
            cur = next
            if (++total > clusterCount) throw IOException("Зацикленная цепочка кластеров")
        }
        out += Run(rf, rl)
        return out
    }

    private fun dirBytes(dir: FsEntry): ByteArray {
        if (dir.firstCluster == 0L && bits != 32) return dev.read(rootDirPos, rootDirBytes)
        val rs = runs(dir.firstCluster, Long.MAX_VALUE)
        val total = rs.sumOf { it.count } * clusterSize
        if (total > 64L * 1024 * 1024) throw IOException("Слишком большой каталог")
        val out = ByteArray(total.toInt())
        var o = 0
        for (r in rs) {
            val n = (r.count * clusterSize).toInt()
            dev.read(clusterPos(r.first), out, o, n)
            o += n
        }
        return out
    }

    private fun rootLabel(): String? = try {
        val d = dirBytes(root)
        var res: String? = null
        var i = 0
        while (i + 32 <= d.size) {
            val f = d.u8(i)
            if (f == 0) break
            if (f != 0xE5 && d.u8(i + 11) and 0x3F == 0x08) { res = d.ascii(i, 11).trimEnd(); break }
            i += 32
        }
        res
    } catch (e: IOException) { null }

    override fun list(dir: FsEntry): List<FsEntry> {
        val d = dirBytes(dir)
        val out = ArrayList<FsEntry>()
        val lfn = CharArray(260)
        var lfnLen = 0
        var lfnSum = -1
        var i = 0
        while (i + 32 <= d.size) {
            val f = d.u8(i)
            if (f == 0) break
            val attr = d.u8(i + 11)
            if (f == 0xE5) { lfnSum = -1; i += 32; continue }
            if (attr and 0x3F == 0x0F) {
                val ord = f and 0x1F
                if (f and 0x40 != 0) { lfnLen = 0; lfnSum = d.u8(i + 13); java.util.Arrays.fill(lfn, '￿') }
                if (ord in 1..20 && d.u8(i + 13) == lfnSum) {
                    val baseIdx = (ord - 1) * 13
                    val offs = intArrayOf(1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30)
                    for (k in 0 until 13) {
                        val c = d.u16(i + offs[k])
                        lfn[baseIdx + k] = c.toChar()
                    }
                    lfnLen = maxOf(lfnLen, baseIdx + 13)
                } else lfnSum = -1
                i += 32
                continue
            }
            if (attr and 0x08 != 0) { lfnSum = -1; i += 32; continue } // volume label
            var name: String? = null
            if (lfnSum >= 0 && shortChecksum(d, i) == lfnSum) {
                var n = 0
                while (n < lfnLen && lfn[n] != '\u0000' && lfn[n] != '￿') n++
                if (n > 0) name = String(lfn, 0, n)
            }
            lfnSum = -1
            if (name == null) name = shortName(d, i)
            if (name == "." || name == "..") { i += 32; continue }
            val isDir = attr and 0x10 != 0
            val cl = (d.u16(i + 20).toLong() shl 16) or d.u16(i + 26).toLong()
            out += FsEntry(
                name = name,
                isDir = isDir,
                size = if (isDir) 0 else d.u32(i + 28),
                mtime = dosTime(d.u16(i + 24), d.u16(i + 22)),
                firstCluster = if (bits == 32) cl else cl and 0xFFFF,
            )
            i += 32
        }
        return out
    }

    override fun open(file: FsEntry): FileStream {
        val need = (file.size + clusterSize - 1) / clusterSize
        val rs = runs(file.firstCluster, need)
        return RunInputStream(dev, rs, clusterSize, ::clusterPos, file.size, file.size)
    }

    private fun shortChecksum(d: ByteArray, i: Int): Int {
        var s = 0
        for (k in 0 until 11) s = ((((s and 1) shl 7) or (s ushr 1)) + d.u8(i + k)) and 0xFF
        return s
    }

    private fun shortName(d: ByteArray, i: Int): String {
        val raw = d.copyOfRange(i, i + 11)
        if (raw[0].toInt() and 0xFF == 0x05) raw[0] = 0xE5.toByte()
        val cs = try { charset("CP866") } catch (e: Exception) { Charsets.ISO_8859_1 }
        var n = String(raw, 0, 8, cs).trimEnd()
        var e = String(raw, 8, 3, cs).trimEnd()
        val nt = d.u8(i + 12)
        if (nt and 0x08 != 0) n = n.lowercase()
        if (nt and 0x10 != 0) e = e.lowercase()
        return if (e.isEmpty()) n else "$n.$e"
    }

    private fun dosTime(date: Int, time: Int): Long {
        if (date == 0) return 0
        val cal = Calendar.getInstance()
        cal.clear()
        cal.set(1980 + (date ushr 9), ((date ushr 5) and 0xF) - 1, date and 0x1F,
            time ushr 11, (time ushr 5) and 0x3F, (time and 0x1F) * 2)
        return cal.timeInMillis
    }

    companion object {
        /** Checks a boot sector for a FAT BPB. Returns type and BPB label. */
        fun probe(b: ByteArray): Pair<FsType, String>? {
            val bps = b.u16(11)
            val spc = b.u8(13)
            val reserved = b.u16(14)
            val nf = b.u8(16)
            if (bps !in intArrayOf(512, 1024, 2048, 4096)) return null
            if (spc == 0 || spc and (spc - 1) != 0) return null
            if (reserved == 0 || nf !in 1..2) return null
            val media = b.u8(21)
            if (media != 0xF0 && media < 0xF8) return null
            val rootEnt = b.u16(17)
            val tot = if (b.u16(19) != 0) b.u16(19).toLong() else b.u32(32)
            val fatSz = if (b.u16(22) != 0) b.u16(22).toLong() else b.u32(36)
            if (tot == 0L || fatSz == 0L) return null
            val rootSec = (rootEnt * 32 + bps - 1) / bps
            val data = tot - reserved - nf * fatSz - rootSec
            if (data <= 0) return null
            val clusters = data / spc
            val type = when {
                clusters < 4085 -> FsType.FAT12
                clusters < 65525 -> FsType.FAT16
                else -> FsType.FAT32
            }
            val lblOff = if (type == FsType.FAT32) 71 else 43
            val sigOff = if (type == FsType.FAT32) 66 else 38
            val lbl = if (b.u8(sigOff) == 0x29) b.ascii(lblOff, 11).trimEnd().takeIf { it != "NO NAME" } ?: "" else ""
            return type to lbl
        }
    }
}
