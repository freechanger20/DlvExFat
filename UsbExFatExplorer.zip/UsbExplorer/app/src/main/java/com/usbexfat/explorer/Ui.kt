package com.usbexfat.explorer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.util.Locale

class Row(val icon: String, val title: String, val sub: String, val enabled: Boolean, val payload: Any?)

fun Context.dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

/** Two-line list rows with an emoji icon. */
class RowsAdapter(private val ctx: Context) : BaseAdapter() {
    var rows: List<Row> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    override fun getCount() = rows.size
    override fun getItem(position: Int) = rows[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun isEnabled(position: Int) = rows[position].enabled

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = (convertView as? LinearLayout) ?: LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), ctx.dp(10))
            addView(TextView(ctx).apply { textSize = 26f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(ctx.dp(44), -2))
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(ctx.dp(10), 0, 0, 0) }
            col.addView(TextView(ctx).apply { textSize = 16f })
            col.addView(TextView(ctx).apply { textSize = 13f; alpha = 0.65f })
            addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val r = rows[position]
        (v.getChildAt(0) as TextView).text = r.icon
        val col = v.getChildAt(1) as LinearLayout
        (col.getChildAt(0) as TextView).text = r.title
        (col.getChildAt(1) as TextView).apply { text = r.sub; visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE }
        v.alpha = if (r.enabled) 1f else 0.45f
        return v
    }
}

fun iconFor(name: String): String = when (extOf(name)) {
    "iso", "img", "vhd", "vhdx", "wim", "esd", "dmg" -> "💿"
    "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp", "svg", "tif", "tiff" -> "🖼️"
    "mp4", "mkv", "avi", "mov", "webm", "ts", "m2ts", "3gp", "wmv", "flv" -> "🎬"
    "mp3", "flac", "wav", "ogg", "m4a", "opus", "aac", "wma" -> "🎵"
    "zip", "rar", "7z", "tar", "gz", "xz", "zst", "bz2", "tgz", "cab" -> "🗜️"
    "apk", "apks", "xapk" -> "📦"
    "pdf", "djvu", "djv" -> "📕"
    "doc", "docx", "odt", "rtf" -> "📘"
    "xls", "xlsx", "ods", "csv" -> "📗"
    "ppt", "pptx", "odp" -> "📙"
    "epub", "fb2", "mobi" -> "📚"
    "efi", "exe", "msi", "bin", "sys", "dll" -> "⚙️"
    else -> if (isTextFile(name)) "📝" else "📄"
}

fun fmtSize(b: Long): String {
    if (b < 1024) return "$b Б"
    val u = arrayOf("КБ", "МБ", "ГБ", "ТБ")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return String.format(Locale.getDefault(), if (v < 10) "%.2f %s" else if (v < 100) "%.1f %s" else "%.0f %s", v, u[i])
}

/** Progress dialog for copy/extract jobs. Methods may be called from any thread. */
class Progress(private val a: Activity, titleText: String, total: Long) {
    @Volatile var cancelled = false
    @Volatile private var total = total
    @Volatile private var done = 0L
    @Volatile private var file = ""
    private val started = SystemClock.elapsedRealtime()
    @Volatile private var lastUi = 0L

    private val text = TextView(a).apply { textSize = 14f }
    private val bar = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
    val dialog: AlertDialog = AlertDialog.Builder(a)
        .setTitle(titleText)
        .setView(LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(24), a.dp(12), a.dp(24), a.dp(4))
            addView(bar); addView(text)
        })
        .setCancelable(false)
        .setNegativeButton("Отмена") { _, _ -> cancelled = true }
        .create()

    fun setTotal(t: Long) { total = t; post(true) }
    fun setFile(n: String) { file = n; post(true) }
    fun add(n: Int) { done += n; post(false) }

    private fun post(force: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastUi < 250) return
        lastUi = now
        a.runOnUiThread { render() }
    }

    fun render() {
        val secs = (SystemClock.elapsedRealtime() - started) / 1000.0
        val speed = if (secs > 0.5) done / secs else 0.0
        bar.isIndeterminate = total <= 0
        if (total > 0) bar.progress = (done * 1000 / total).toInt()
        text.text = buildString {
            if (file.isNotEmpty()) append(file).append('\n')
            append(fmtSize(done))
            if (total > 0) append(" из ").append(fmtSize(total))
            if (speed > 0) append(" · ").append(fmtSize(speed.toLong())).append("/с")
        }
    }
}

fun copyWithProgress(input: java.io.InputStream, out: java.io.OutputStream, p: Progress) {
    val buf = ByteArray(1024 * 1024)
    while (!p.cancelled) {
        val r = input.read(buf)
        if (r < 0) break
        out.write(buf, 0, r)
        p.add(r)
    }
}

fun safeName(n: String) = n.replace('/', '_').replace('\u0000', '_').ifBlank { "_" }

fun Activity.toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_LONG).show()

fun Activity.showError(title: String, e: Throwable) {
    AlertDialog.Builder(this).setTitle(title).setMessage(e.message ?: e.toString()).setPositiveButton("OK", null).show()
}

/** Runs a long job with a progress dialog; [onDone] is called on the UI thread unless cancelled. */
fun <T> Activity.runJob(title: String, total: Long, executor: java.util.concurrent.Executor, job: (Progress) -> T, onDone: (T) -> Unit) {
    val p = Progress(this, title, total)
    p.dialog.show()
    p.render()
    window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    executor.execute {
        val res = runCatching { job(p) }
        runOnUiThread {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (isDestroyed) return@runOnUiThread
            p.dialog.dismiss()
            res.fold({ if (p.cancelled) toast("Отменено") else onDone(it) }, { showError("Ошибка", it) })
        }
    }
}

/** Removes old extracted/copied files so the cache doesn't grow forever. */
fun cleanOpenCache(ctx: android.content.Context) {
    val now = System.currentTimeMillis()
    FilesProvider.cacheDir(ctx).listFiles()?.forEach { if (now - it.lastModified() > 30 * 60_000L) it.delete() }
}
