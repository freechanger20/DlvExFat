package com.usbexfat.explorer.fs

import java.io.IOException

/** Raw block device: USB drive (or an image file in tests). */
interface BlockDevice {
    val blockSize: Int
    val blockCount: Long
    /** Max blocks per one read call, the caller splits bigger reads. */
    val maxBlocksPerRead: Int

    @Throws(IOException::class)
    fun readBlocks(lba: Long, count: Int, buf: ByteArray, off: Int)

    fun close() {}
}

/**
 * Byte-addressed view over a block device with a small LRU chunk cache.
 * Small reads (directories, FAT) go through the cache, big sequential
 * reads (file contents) go directly to the device.
 */
class ByteDevice(val dev: BlockDevice) {
    val size: Long get() = dev.blockCount * dev.blockSize

    private val bs = dev.blockSize
    private val chunkBlocks = maxOf(1, CHUNK_BYTES / bs)
    private val chunkBytes = chunkBlocks * bs

    private val cache = object : LinkedHashMap<Long, ByteArray>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, ByteArray>?): Boolean =
            size > CACHE_CHUNKS
    }

    @Synchronized
    @Throws(IOException::class)
    fun read(pos: Long, buf: ByteArray, off: Int, len: Int) {
        if (len <= 0) return
        if (pos < 0 || pos + len > size) throw IOException("Чтение за пределами устройства: $pos+$len")
        if (len >= DIRECT_THRESHOLD) readDirect(pos, buf, off, len) else readCached(pos, buf, off, len)
    }

    fun read(pos: Long, len: Int): ByteArray = ByteArray(len).also { read(pos, it, 0, len) }

    private fun chunk(index: Long): ByteArray {
        cache[index]?.let { return it }
        val firstLba = index * chunkBlocks
        val n = minOf(chunkBlocks.toLong(), dev.blockCount - firstLba).toInt()
        val data = ByteArray(chunkBytes)
        readBlocksSplit(firstLba, n, data, 0)
        cache[index] = data
        return data
    }

    private fun readCached(pos: Long, buf: ByteArray, off: Int, len: Int) {
        var p = pos
        var o = off
        var left = len
        while (left > 0) {
            val idx = p / chunkBytes
            val inChunk = (p % chunkBytes).toInt()
            val n = minOf(left, chunkBytes - inChunk)
            System.arraycopy(chunk(idx), inChunk, buf, o, n)
            p += n; o += n; left -= n
        }
    }

    private fun readDirect(pos: Long, buf: ByteArray, off: Int, len: Int) {
        val firstLba = pos / bs
        val lastLba = (pos + len - 1) / bs
        val head = (pos % bs).toInt()
        val nBlocks = (lastLba - firstLba + 1).toInt()
        if (head == 0 && len % bs == 0) {
            readBlocksSplit(firstLba, nBlocks, buf, off)
        } else {
            val tmp = ByteArray(nBlocks * bs)
            readBlocksSplit(firstLba, nBlocks, tmp, 0)
            System.arraycopy(tmp, head, buf, off, len)
        }
    }

    private fun readBlocksSplit(lba: Long, count: Int, buf: ByteArray, off: Int) {
        var l = lba
        var c = count
        var o = off
        val max = maxOf(1, dev.maxBlocksPerRead)
        while (c > 0) {
            val n = minOf(c, max)
            dev.readBlocks(l, n, buf, o)
            l += n; c -= n; o += n * bs
        }
    }

    @Synchronized
    fun clearCache() = cache.clear()

    companion object {
        private const val CHUNK_BYTES = 32 * 1024
        private const val CACHE_CHUNKS = 128 // 4 MiB
        private const val DIRECT_THRESHOLD = 64 * 1024
    }
}

internal fun ByteArray.u8(i: Int): Int = this[i].toInt() and 0xFF
internal fun ByteArray.u16(i: Int): Int = u8(i) or (u8(i + 1) shl 8)
internal fun ByteArray.u32(i: Int): Long = (u16(i).toLong()) or (u16(i + 2).toLong() shl 16)
internal fun ByteArray.u64(i: Int): Long = u32(i) or (u32(i + 4) shl 32)
internal fun ByteArray.ascii(i: Int, n: Int): String = String(this, i, n, Charsets.US_ASCII)
