package com.usbexfat.explorer.fs

import java.io.IOException
import java.io.InputStream

/** Read-only NTFS driver (no compression / encryption). */
class NtfsFs(private val dev: ByteDevice, private val base: Long) : FileSystem {
    override val typeName = "NTFS"
    override val label: String
    override val root: FsEntry

    private val clusterSize: Long
    private val recSize: Int
    private var mftExtents: List<Extent>
    private var mftSize: Long

    /** Contiguous piece of an attribute: vcn → lcn (lcn < 0 = sparse hole). */
    class Extent(val vcn: Long, val lcn: Long, val len: Long)

    private class Attr(
        val type: Int,
        val name: String,
        val nonResident: Boolean,
        val flags: Int,
        val value: ByteArray?,
        val startVcn: Long,
        val extents: List<Extent>,
        val dataSize: Long,
        val initSize: Long,
        val compUnit: Int,
    )

    init {
        val b = dev.read(base, 512)
        if (b.ascii(3, 8) != "NTFS    ") throw IOException("Это не NTFS")
        val bps = b.u16(11)
        val spcRaw = b.u8(13)
        val spc = if (spcRaw <= 0x80) spcRaw else 1 shl (256 - spcRaw)
        if (bps !in intArrayOf(512, 1024, 2048, 4096) || spc == 0) throw IOException("Повреждён загрузочный сектор NTFS")
        clusterSize = bps.toLong() * spc
        val mftLcn = b.u64(48)
        recSize = sizeField(b[64].toInt())
        if (recSize < 256 || recSize > 65536) throw IOException("Неверный размер записи MFT")

        // Bootstrap $MFT: record 0 sits at the start of the MFT
        val rec0 = dev.read(base + mftLcn * clusterSize, recSize)
        if (!fixup(rec0, 0, recSize, "FILE")) throw IOException("Повреждена запись \$MFT")
        val a0 = parseAttrs(rec0)
        val d0 = a0.firstOrNull { it.type == AT_DATA && it.name.isEmpty() } ?: throw IOException("Нет \$DATA у \$MFT")
        mftExtents = d0.extents
        mftSize = d0.dataSize
        if (a0.any { it.type == AT_ATTRIBUTE_LIST }) {
            val all = loadAttrs(0, rec0)
            val d = mergedData(all, AT_DATA, "") ?: throw IOException("Нет \$DATA у \$MFT")
            mftExtents = d.extents
            mftSize = d.dataSize
        }
        root = FsEntry("", true, 0, 0, ROOT_REF)
        label = try {
            loadAttrs(3).firstOrNull { it.type == AT_VOLUME_NAME }?.value?.let { utf16(it, 0, it.size / 2) } ?: ""
        } catch (e: IOException) { "" }
    }

    private fun sizeField(v: Int): Int {
        val s = v.toByte().toInt()
        return if (s > 0) (s * clusterSize).toInt() else 1 shl (-s)
    }

    // ------------------------------------------------------------- records

    private fun readRecord(ref: Long): ByteArray {
        val off = ref * recSize
        if (off + recSize > mftSize) throw IOException("Запись MFT $ref за пределами таблицы")
        val buf = ByteArray(recSize)
        readExtents(mftExtents, clusterSize, off, buf, 0, recSize)
        if (!fixup(buf, 0, recSize, "FILE")) throw IOException("Повреждена запись MFT $ref")
        return buf
    }

    private fun fixup(b: ByteArray, off: Int, len: Int, magic: String): Boolean {
        if (b.ascii(off, 4) != magic) return false
        val usaOfs = b.u16(off + 4)
        val usaCnt = b.u16(off + 6)
        if (usaOfs + usaCnt * 2 > len) return false
        val usn = b.u16(off + usaOfs)
        for (i in 1 until usaCnt) {
            val p = off + i * 512 - 2
            if (p + 2 > off + len) break
            if (b.u16(p) != usn) return false
            b[p] = b[off + usaOfs + 2 * i]
            b[p + 1] = b[off + usaOfs + 2 * i + 1]
        }
        return true
    }

    private fun parseAttrs(rec: ByteArray): List<Attr> {
        val out = ArrayList<Attr>()
        var p = rec.u16(20)
        while (p + 16 <= rec.size) {
            val type = rec.u32(p).toInt()
            if (type == -1) break
            val len = rec.u32(p + 4).toInt()
            if (len < 16 || p + len > rec.size) break
            val nonRes = rec.u8(p + 8) != 0
            val nameLen = rec.u8(p + 9)
            val name = if (nameLen > 0) utf16(rec, p + rec.u16(p + 10), nameLen) else ""
            val flags = rec.u16(p + 12)
            if (!nonRes) {
                val vl = rec.u32(p + 16).toInt()
                val vo = rec.u16(p + 20)
                val v = rec.copyOfRange(p + vo, minOf(p + vo + vl, rec.size))
                out += Attr(type, name, false, flags, v, 0, emptyList(), v.size.toLong(), v.size.toLong(), 0)
            } else {
                val startVcn = rec.u64(p + 16)
                val runOff = rec.u16(p + 32)
                val cu = rec.u16(p + 34)
                val ext = decodeRuns(rec, p + runOff, p + len, startVcn)
                out += Attr(type, name, true, flags, null, startVcn, ext, rec.u64(p + 48), rec.u64(p + 56), cu)
            }
            p += len
        }
        return out
    }

    private fun decodeRuns(b: ByteArray, start: Int, end: Int, startVcn: Long): List<Extent> {
        val out = ArrayList<Extent>()
        var p = start
        var vcn = startVcn
        var lcn = 0L
        while (p < end) {
            val h = b.u8(p)
            if (h == 0) break
            val ls = h and 0x0F
            val os = h ushr 4
            p++
            if (ls == 0 || ls > 8 || os > 8 || p + ls + os > end) break
            var len = 0L
            for (k in 0 until ls) len = len or (b.u8(p + k).toLong() shl (8 * k))
            if (os == 0) {
                out += Extent(vcn, -1, len)
            } else {
                var d = 0L
                for (k in 0 until os) d = d or (b.u8(p + ls + k).toLong() shl (8 * k))
                if (b[p + ls + os - 1] < 0 && os < 8) d = d or (-1L shl (8 * os)) // sign extend
                lcn += d
                out += Extent(vcn, lcn, len)
            }
            p += ls + os
            vcn += len
        }
        return out
    }

    /** All attributes of a file, including those moved to extension records. */
    private fun loadAttrs(ref: Long, preRead: ByteArray? = null): List<Attr> {
        val rec = preRead ?: readRecord(ref)
        val attrs = parseAttrs(rec)
        val list = attrs.firstOrNull { it.type == AT_ATTRIBUTE_LIST } ?: return attrs
        val lb = attrValue(list)
        val ext = LinkedHashSet<Long>()
        var p = 0
        while (p + 26 <= lb.size) {
            val l = lb.u16(p + 4)
            if (l < 26) break
            val r = lb.u64(p + 16) and REF_MASK
            if (r != ref) ext += r
            p += l
        }
        val out = ArrayList(attrs)
        for (r in ext) out += parseAttrs(readRecord(r))
        return out
    }

    private fun attrValue(a: Attr): ByteArray {
        if (!a.nonResident) return a.value!!
        if (a.dataSize > 64L * 1024 * 1024) throw IOException("Слишком большой атрибут")
        val b = ByteArray(a.dataSize.toInt())
        readExtents(a.extents, clusterSize, 0, b, 0, b.size, a.initSize)
        return b
    }

    /** Joins pieces of one non-resident attribute that are spread over several records. */
    private fun mergedData(attrs: List<Attr>, type: Int, name: String): Attr? {
        val parts = attrs.filter { it.type == type && it.name == name }
        if (parts.isEmpty()) return null
        if (parts.size == 1 || !parts[0].nonResident) return parts[0]
        val sorted = parts.sortedBy { it.startVcn }
        val first = sorted[0]
        return Attr(type, name, true, first.flags, null, 0, sorted.flatMap { it.extents }, first.dataSize, first.initSize, first.compUnit)
    }

    // ------------------------------------------------------------- data access

    private fun readExtents(ext: List<Extent>, cs: Long, pos: Long, buf: ByteArray, off: Int, len: Int, initSize: Long = Long.MAX_VALUE) {
        var p = pos
        var o = off
        var left = len
        while (left > 0) {
            if (p >= initSize) { java.util.Arrays.fill(buf, o, o + left, 0); return }
            val vcn = p / cs
            val e = findExtent(ext, vcn) ?: throw IOException("Нет кластера для VCN $vcn")
            val inExt = (p - e.vcn * cs)
            var n = minOf(left.toLong(), e.len * cs - inExt, initSize - p).toInt()
            if (n <= 0) n = minOf(left.toLong(), e.len * cs - inExt).toInt()
            if (e.lcn < 0) java.util.Arrays.fill(buf, o, o + n, 0)
            else dev.read(base + e.lcn * cs + inExt, buf, o, n)
            p += n; o += n; left -= n
        }
    }

    private fun findExtent(ext: List<Extent>, vcn: Long): Extent? {
        var lo = 0
        var hi = ext.size - 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            val e = ext[mid]
            when {
                vcn < e.vcn -> hi = mid - 1
                vcn >= e.vcn + e.len -> lo = mid + 1
                else -> return e
            }
        }
        return null
    }

    private inner class AttrStream(private val a: Attr) : FileStream() {
        override val length = a.dataSize
        override fun readAt(pos: Long, b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            if (pos >= a.dataSize) return -1
            val n = minOf(len.toLong(), a.dataSize - pos, 4L * 1024 * 1024).toInt()
            readExtents(a.extents, clusterSize, pos, b, off, n, a.initSize)
            return n
        }
    }

    override fun open(file: FsEntry): FileStream {
        val attrs = loadAttrs(file.firstCluster)
        val d = mergedData(attrs, AT_DATA, "") ?: return BytesStream(ByteArray(0))
        if (d.flags and 0x4000 != 0) throw IOException("Файл зашифрован (EFS), прочитать нельзя")
        if (d.flags and 0x00FF != 0) throw IOException("Файл сжат средствами NTFS — такие файлы пока не поддерживаются")
        return if (!d.nonResident) BytesStream(d.value!!) else AttrStream(d)
    }

    // ------------------------------------------------------------- directories

    override fun list(dir: FsEntry): List<FsEntry> {
        val attrs = loadAttrs(dir.firstCluster)
        val rootAttr = attrs.firstOrNull { it.type == AT_INDEX_ROOT && it.name == "\$I30" }
            ?: throw IOException("Это не папка")
        val keys = ArrayList<ByteArray>()
        val rv = attrValue(rootAttr)
        val blockSize = rv.u32(8).toInt()
        collectEntries(rv, 16, keys)
        val alloc = mergedData(attrs, AT_INDEX_ALLOCATION, "\$I30")
        if (alloc != null && alloc.nonResident && blockSize > 0) {
            val bmp = mergedData(attrs, AT_BITMAP, "\$I30")?.let { attrValue(it) }
            val nBlocks = (alloc.dataSize / blockSize).toInt()
            val blk = ByteArray(blockSize)
            for (i in 0 until nBlocks) {
                if (bmp != null && (i / 8 >= bmp.size || (bmp.u8(i / 8) shr (i % 8)) and 1 == 0)) continue
                readExtents(alloc.extents, clusterSize, i.toLong() * blockSize, blk, 0, blockSize, alloc.initSize)
                if (!fixup(blk, 0, blockSize, "INDX")) continue
                collectEntries(blk, 24, keys)
            }
        }
        val seen = HashSet<String>()
        val out = ArrayList<FsEntry>()
        for (k in keys) {
            val ref = k.u64(0) and REF_MASK
            val fnFlags = k.u32(8 + 56).toInt()
            val nameLen = k.u8(8 + 64)
            val ns = k.u8(8 + 65)
            if (ns == 2) continue // DOS 8.3 alias
            if (ref < 24) continue // NTFS metadata files
            if (fnFlags and 0x6 == 0x6) continue // hidden + system
            val name = utf16(k, 8 + 66, nameLen)
            if (!seen.add("$ref/$name")) continue
            val isDir = fnFlags and 0x10000000 != 0
            var size = k.u64(8 + 48)
            var mtime = filetime(k.u64(8 + 16))
            try {
                val fa = loadAttrs(ref)
                fa.firstOrNull { it.type == AT_STANDARD_INFORMATION }?.value?.let { if (it.size >= 16) mtime = filetime(it.u64(8)) }
                if (!isDir) mergedData(fa, AT_DATA, "")?.let { size = it.dataSize }
            } catch (_: IOException) {}
            out += FsEntry(name, isDir, if (isDir) 0 else size, mtime, ref)
        }
        return out
    }

    /** Index header at [h]: collects FILE_NAME keys (prefixed with the 8-byte file reference). */
    private fun collectEntries(b: ByteArray, h: Int, out: MutableList<ByteArray>) {
        var p = h + b.u32(h).toInt()
        val end = minOf(b.size, h + b.u32(h + 4).toInt())
        while (p + 16 <= end) {
            val len = b.u16(p + 8)
            val keyLen = b.u16(p + 10)
            val flags = b.u16(p + 12)
            if (flags and 2 != 0 || len < 16) break
            if (keyLen >= 66 && p + 16 + keyLen <= b.size) {
                val k = ByteArray(8 + keyLen)
                System.arraycopy(b, p, k, 0, 8)
                System.arraycopy(b, p + 16, k, 8, keyLen)
                out += k
            }
            p += len
        }
    }

    private fun utf16(b: ByteArray, off: Int, chars: Int): String {
        val c = CharArray(chars)
        for (i in 0 until chars) c[i] = b.u16(off + i * 2).toChar()
        return String(c)
    }

    private fun filetime(ft: Long): Long = if (ft <= 0) 0 else ft / 10_000 - 11_644_473_600_000L

    companion object {
        private const val ROOT_REF = 5L
        private const val REF_MASK = 0x0000FFFFFFFFFFFFL
        private const val AT_STANDARD_INFORMATION = 0x10
        private const val AT_ATTRIBUTE_LIST = 0x20
        private const val AT_VOLUME_NAME = 0x60
        private const val AT_DATA = 0x80
        private const val AT_INDEX_ROOT = 0x90
        private const val AT_INDEX_ALLOCATION = 0xA0
        private const val AT_BITMAP = 0xB0
    }
}
