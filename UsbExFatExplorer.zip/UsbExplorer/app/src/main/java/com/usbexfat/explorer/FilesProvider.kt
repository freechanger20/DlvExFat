package com.usbexfat.explorer

import android.annotation.TargetApi
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.os.ProxyFileDescriptorCallback
import android.os.storage.StorageManager
import android.provider.OpenableColumns
import android.system.ErrnoException
import android.system.OsConstants
import com.usbexfat.explorer.fs.FileSystem
import com.usbexfat.explorer.fs.FsEntry
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Gives other apps access to files:
 *  content://AUTH/usb/<id>/<name>   – file read live from the USB drive (seekable on Android 8+)
 *  content://AUTH/cache/<name>      – file extracted to the app cache (e.g. from a ZIP)
 */
class FilesProvider : ContentProvider() {

    class Item(val fs: FileSystem, val entry: FsEntry)

    override fun onCreate() = true

    override fun getType(uri: Uri): String = mimeOf(uri.lastPathSegment ?: "")

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val (name, size) = when (uri.pathSegments.firstOrNull()) {
            "usb" -> item(uri).let { it.entry.name to it.entry.size }
            "cache" -> cacheFile(uri).let { it.name to it.length() }
            else -> throw FileNotFoundException()
        }
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val c = MatrixCursor(cols)
        c.addRow(cols.map { col ->
            when (col) {
                OpenableColumns.DISPLAY_NAME -> name
                OpenableColumns.SIZE -> size
                else -> null
            }
        })
        return c
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode.contains('w')) throw FileNotFoundException("Только чтение")
        return when (uri.pathSegments.firstOrNull()) {
            "cache" -> ParcelFileDescriptor.open(cacheFile(uri), ParcelFileDescriptor.MODE_READ_ONLY)
            "usb" -> {
                val it = item(uri)
                if (Build.VERSION.SDK_INT >= 26) proxy(context!!, it) else pipe(it)
            }
            else -> throw FileNotFoundException()
        }
    }

    private fun item(uri: Uri): Item {
        val id = uri.pathSegments.getOrNull(1) ?: throw FileNotFoundException()
        return items[id] ?: throw FileNotFoundException("Файл больше недоступен — откройте его заново")
    }

    private fun cacheFile(uri: Uri): File {
        val dir = cacheDir(context!!)
        val f = File(dir, uri.lastPathSegment ?: throw FileNotFoundException())
        if (f.canonicalFile.parentFile != dir.canonicalFile || !f.exists()) throw FileNotFoundException()
        return f
    }

    @TargetApi(26)
    private fun proxy(ctx: Context, item: Item): ParcelFileDescriptor {
        val stream = try { item.fs.open(item.entry) } catch (e: IOException) { throw FileNotFoundException(e.message) }
        val sm = ctx.getSystemService(StorageManager::class.java)
        return sm.openProxyFileDescriptor(ParcelFileDescriptor.MODE_READ_ONLY, object : ProxyFileDescriptorCallback() {
            override fun onGetSize(): Long = stream.length
            override fun onRead(offset: Long, size: Int, data: ByteArray): Int {
                var got = 0
                try {
                    while (got < size) {
                        val r = stream.readAt(offset + got, data, got, size - got)
                        if (r <= 0) break
                        got += r
                    }
                } catch (e: IOException) {
                    throw ErrnoException("read", OsConstants.EIO)
                }
                return got
            }
            override fun onRelease() {}
        }, proxyHandler)
    }

    private fun pipe(item: Item): ParcelFileDescriptor {
        val p = ParcelFileDescriptor.createReliablePipe()
        Thread {
            try {
                ParcelFileDescriptor.AutoCloseOutputStream(p[1]).use { out ->
                    item.fs.open(item.entry).use { it.copyTo(out, 256 * 1024) }
                }
            } catch (e: Exception) {
                try { p[1].closeWithError(e.message) } catch (_: Exception) {}
            }
        }.start()
        return p[0]
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?) = 0

    companion object {
        const val AUTHORITY = "com.usbexfat.explorer.files"
        private val items = ConcurrentHashMap<String, Item>()
        private val nextId = AtomicLong(1)
        private val proxyHandler: Handler by lazy {
            Handler(HandlerThread("usb-proxy").apply { start() }.looper)
        }

        fun cacheDir(ctx: Context) = File(ctx.cacheDir, "open").also { it.mkdirs() }

        /** Registers a USB file and returns a content URI for it. */
        fun usbUri(fs: FileSystem, e: FsEntry): Uri {
            val id = nextId.getAndIncrement().toString()
            items[id] = Item(fs, e)
            return Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("usb").appendPath(id).appendPath(e.name).build()
        }

        fun cacheUri(name: String): Uri =
            Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("cache").appendPath(name).build()

        /** Drops all USB links (drive disconnected). */
        fun clearUsb() = items.clear()
    }
}
